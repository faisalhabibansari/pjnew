var token = context.getVariable('request.header.access_token');

context.setVariable("APIGEEACCESSTOKEN",token);