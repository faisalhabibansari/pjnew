//Will sub this in once core URL is available
/*var url = 'http://t-mobile-prod.apigee.net/paymentcard/authorization?CartId=1234';

var req = httpClient.get(url); 
req.waitForComplete();*/

//Core response
//response.content = '{ "PaymentTransactionId": { "PaymentTransactionId": "PaymentTransactionId" }, "PaymentTransactionResponse": { "paymentTransactionId": "paymentTransactionId", "actionTypeCode": "actionTypeCode", "responseCode": "responseCode", "paymentSystemCode": "ACCEPT", "authorizationTime": "authorizationTime", "authorizedAmount": { "currencyCode": "currencyCode" }, "additionalResponseData": [ "additionalResponseData" ], "errorCode": "errorCode", "errorDescription": "errorDescription", "avsResponseCode": "avsResponseCode", "securityCheckResponseCode": "securityCheckResponseCode", "traceNumber": "traceNumber", "debitNetworkCode": "debitNetworkCode", "settlementDate": "settlementDate", "balanceAmount": [ { "currencyCode": "currencyCode", "name": "name" } ], "responseStatus": { "statusCode": "statusCode", "name": "name", "description": [ { "languageCode": "languageCode", "usageContext": "usageContext" } ], "effectivePeriod": { "startTime": "startTime", "duration": "duration", "endTime": "endTime" }, "reasonCode": "reasonCode" }, "fraudCheckStatus": { "statusCode": "100", "name": "name", "description": [ { "languageCode": "languageCode", "usageContext": "usageContext" } ], "effectivePeriod": { "startTime": "startTime", "duration": "duration", "endTime": "endTime" }, "reasonCode": "reasonCode" }, "missingFields": { "missingFieldName": [ "missingFieldName" ] }, "invalidFields": { "invalidFieldName": [ "invalidFieldName" ] }, "paymenInstrumentAlias": "paymenInstrumentAlias", "paymentTransactionStatus": [ { "statusCode": "statusCode", "name": "name", "description": [ { "languageCode": "languageCode", "usageContext": "usageContext" } ], "effectivePeriod": { "startTime": "startTime", "duration": "duration", "endTime": "endTime" }, "reasonCode": "reasonCode" } ], "specificationGroup": [ { "name": "name", "specificationValue": [ { "currencyCode": "currencyCode", "dataType": "dataType", "measurementUnit": "measurementUnit", "precision": 1, "scale": 1, "name": "name", "value": "value" } ] } ], "fraudCheckRequestId": "fraudCheckRequestId" } }'

//Mock response
response.content = '{"transactionId":"SX34d1","status":"success"}';

//http://t-mobile-prod.apigee.net/payment/history?financialAccountNumber=1234&startDate=2014-12-17&endDate=2014-12-18	

