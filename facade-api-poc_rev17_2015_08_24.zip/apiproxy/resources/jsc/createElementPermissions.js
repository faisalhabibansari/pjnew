/*

Purpose: The script is aimed to store mock object information into BaaS.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:

7 April | Documentation Headers Added

*/

// Grab variables from context
var reqContent = context.getVariable('request.content');
var routeName = context.getVariable("routeName");

// Constants
var ACTION_TYPE_CREATE="CREATE";
var OBJ_DATA_TYPE='elementPermission';


/*
function to update Baas role-route object
inputs::
  routeObjUUID: String (object Id)
  roleName: String
  routePermissionPayload: JSON Object (for routes to be updated)
*/
function fnPostRoutePermissions(rName, routePermissionPayload, actionType)
{
  
  var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks";

// 
  context.setVariable('fnPostRoutePermissions.rName', rName);  
  context.setVariable('fnPostRoutePermissions.routePermissionPayload', JSON.stringify(routePermissionPayload));
  context.setVariable('fnPostRoutePermissions.actionType', actionType);  
  
  // Set Headers for posting data 
  var headers = {'Content-Type' : 'application/json'};
  
  //Create Role Route Object to be updated
  var mObj = {};
  
  mObj.dataType=OBJ_DATA_TYPE;
  mObj.id=rName;
  mObj.mockData=routePermissionPayload;
  
  //Create request object with payload and headers
  var reqPayload = JSON.stringify(mObj);  
 
  context.setVariable('fnPostRoutePermissions.reqPayload', reqPayload); 
  
  var myRequest;

  if(actionType==ACTION_TYPE_CREATE)
  {
    myRequest = new Request(url,"POST",headers, reqPayload);
  }
  
  var req = httpClient.send(myRequest);

  req.waitForComplete();
  
  if (req.isSuccess()) {
    //
    context.setVariable('req.isSuccess()', req.isSuccess());
  }
  
}


/*
utility function to extract request payload elements
*/
function extractRouteReqPayload(reqPayloadContent)
{
  
  context.setVariable('reqPayloadContent', reqPayloadContent);

  
    if((reqPayloadContent!=null)&&(reqPayloadContent!=''))
    {
        
        var prxyRequestPayload = JSON.parse(reqPayloadContent);
    	
      	context.setVariable('prxyRequestPayload', prxyRequestPayload);
        
      	return prxyRequestPayload;
     }      
}




/*

  
*/

function fnGetElementPermissions(rName)
{

  var url = "";

  if((rName!=null)&&(rName!=''))
  {
      context.setVariable('fnGetElementPermissions.trace', rName);
      
    	url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='elementPermission' and id=" + "'" + rName + "'";
  }
    
       
	var headers = {'Content-Type' : 'application/json'};
    
  	var myRequest = new Request(url,"GET",headers);
    
  	var req = httpClient.send(myRequest);
      
    req.waitForComplete();    

    if (req.isSuccess()) {
      
      
      var mData = req.getResponse().content.asJSON;
      
      return mData;
      
    }           
}



/*
main function to process request payload and post updated data
*/
function processCreateReqPayload(rName, requestPayloadContent)
{
  try 
  {
   
	context.setVariable('processCreateReqPayload.routeName', rName);
    
	var respObj = fnGetElementPermissions(rName);

      //no object exists for the input routeName, proceed with create action
      if( respObj.entities.length==0)
      {
		fnPostRoutePermissions(rName, requestPayloadContent, ACTION_TYPE_CREATE);            
      }         
  }
  catch(err)
  {
    context.setVariable('err', err);
  }

}

context.setVariable('reqContent', reqContent);

var parsedReqContent = extractRouteReqPayload(reqContent);
processCreateReqPayload(routeName, parsedReqContent);