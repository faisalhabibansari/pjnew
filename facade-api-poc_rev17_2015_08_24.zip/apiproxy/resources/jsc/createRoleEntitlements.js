/*

Purpose: The script is aimed to store mock object information into BaaS.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:

7 April | Documentation Headers Added

*/

// Grab variables from context
var reqContent = context.getVariable('request.content');
var roleName = context.getVariable("roleName");

// Constants
var ACTION_TYPE_CREATE="CREATE";
var OBJ_DATA_TYPE='roleEntitlement';


/*
function to update Baas role-route object
inputs::
  routeObjUUID: String (object Id)
  roleName: String
  roleEntitlementPayload: JSON Object (for routes to be updated)
*/
function fnPostRoleEntitlements(rName, roleEntitlementPayload, actionType)
{
  
  var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks";

// 
  context.setVariable('fnPostRoleEntitlements.roleName', roleName);  
  context.setVariable('fnPostRoleEntitlements.roleEntitlementPayload', JSON.stringify(roleEntitlementPayload));
  context.setVariable('fnPostRoleEntitlements.actionType', actionType);  
  
  // Set Headers for posting data 
  var headers = {'Content-Type' : 'application/json'};
  
  //Create Role Route Object to be updated
  var mObj = {};
  
  mObj.dataType=OBJ_DATA_TYPE;
  mObj.id=roleName;
  mObj.mockData=roleEntitlementPayload;
  
  //Create request object with payload and headers
  var reqPayload = JSON.stringify(mObj);  
 
  context.setVariable('fnPostRoleEntitlements.reqPayload', reqPayload); 
  
  var myRequest;

  if(actionType==ACTION_TYPE_CREATE)
  {
    myRequest = new Request(url,"POST",headers, reqPayload);
  }
  
  var req = httpClient.send(myRequest);

  req.waitForComplete();
  
  if (req.isSuccess()) {
    //
    context.setVariable('req.isSuccess()', req.isSuccess());
  }
  
}


/*
utility function to extract request payload elements
*/
function extractRoleReqPayload(reqPayloadContent)
{
  
  context.setVariable('reqPayloadContent', reqPayloadContent);

  
    if((reqPayloadContent!=null)&&(reqPayloadContent!=''))
    {
        
        var prxyRequestPayload = JSON.parse(reqPayloadContent);
    	
      	context.setVariable('prxyRequestPayload', prxyRequestPayload);
        
      	return prxyRequestPayload;
     }      
}




/*

  
*/

function fnGetEntitlements(roleName)
{

  var url = "";

  if((roleName!=null)&&(roleName!=''))
  {
      context.setVariable('fnGetGetEntitlements.trace', roleName);
      
    	url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='roleEntitlement' and id=" + "'" + roleName + "'";
  }
    
       
	var headers = {'Content-Type' : 'application/json'};
    
  	var myRequest = new Request(url,"GET",headers);
    
  	var req = httpClient.send(myRequest);
      
    req.waitForComplete();    

    if (req.isSuccess()) {
      
      
      var mData = req.getResponse().content.asJSON;
      
      return mData;
      
    }           
}



/*
main function to process request payload and post updated data
*/
function processCreateReqPayload(roleName, requestPayloadContent)
{
  try 
  {
   
	context.setVariable('processCreateReqPayload.roleName', roleName);
    
	var respObj = fnGetEntitlements(roleName);

      //no object exists for the input routeName, proceed with create action
      if( respObj.entities.length==0)
      {
		fnPostRoleEntitlements(roleName, requestPayloadContent, ACTION_TYPE_CREATE);            
      }         
  }
  catch(err)
  {
    context.setVariable('err', err);
  }

}

context.setVariable('reqContent', reqContent);

var parsedReqContent = extractRoleReqPayload(reqContent);
processCreateReqPayload(roleName, parsedReqContent);