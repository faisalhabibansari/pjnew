/*

Script: exchangeAuthCode.js

*/

  var FLAG_ESERV_CUST = "redirectToEService";
  var FLAG_REBELLION_CUST = "processInRebellion";

  function getAuthenticatedUserDetail(rebellionCustomerFlag, iamProfile, iamAccessToken)
  {
    
    var iam_profile = iamProfile;
    
    var iam_access_token = iamAccessToken;
    
    var responseBody = {};
    
    responseBody.response = rebellionCustomerFlag;
    
    responseBody.profile = iam_profile;
    
    responseBody.iam_access_token = iam_access_token;
    
    //responseBody.facade_access_token = authResponseCont.access_token;    
    
    var s = JSON.stringify(iam_profile);
    
    var p = JSON.parse(s);
    
    var permObjId = p.TMO_ID_profile.impi1;
    
    context.setVariable("permObjId", permObjId);
    
    var permObj = getPermissions(permObjId);
    
    context.setVariable("permObj", permObj);
    
    responseBody.permissions = permObj;
    
    responseBody.dataCenterSegmentationId = "titan";     
    
    context.setVariable("responseBody", JSON.stringify(responseBody));
    
    return JSON.stringify(responseBody);
    
  }

  //URL for third party access management system
  var url = 'https://66.94.14.141/userprofile/p/v1/userinfo';

  var responseFrmOAuth = JSON.stringify(response.content)
  context.setVariable("responseFrmOAuth", responseFrmOAuth);
  //remove newline, tab etc characters from the response
  var s = escSpecialChars(responseFrmOAuth);

  var authResponseCont = JSON.parse(s);
  context.setVariable("authResponseCont", authResponseCont);
  context.setVariable("authResponseCont.access_token", authResponseCont.access_token);

  // Grab access token from context
  var iam_access_token = context.getVariable('iam_access_token');
  
  var bearer = "Bearer " + iam_access_token;
  context.setVariable("Bearer", bearer);
  
  var headers = {"Authorization": "Bearer " + iam_access_token};
  
  try
  {
    
    var myRequest = new Request(url,"GET",headers);
    var req = httpClient.send(myRequest);
    
    req.waitForComplete();
    
    var response = req.getResponse();
    
    if(response.status == 200) {
    
      var iam_profile_asJSON = response.content.asJSON;
      var iam_profile = response.content;
      
      context.setVariable("iam_profile", JSON.stringify(iam_profile));
      
      msisdn = iam_profile_asJSON.associated_lines.lines[0].MSISDN;
      context.setVariable('msisdn', msisdn);
      
      var hostSystemRespObj = {};
      hostSystemRespObj = fnGetHostSystem(msisdn);
      
      context.setVariable('hostSystemRespObj', JSON.stringify(hostSystemRespObj));
      
      if((hostSystemRespObj!=null)&&(hostSystemRespObj.response!=null))      
      {
        context.setVariable('hostSystemRespObj.response', JSON.stringify(hostSystemRespObj.response));

        if(hostSystemRespObj.response==FLAG_ESERV_CUST)
        {
          context.proxyResponse.content = hostSystemRespObj;
        }
        else if(hostSystemRespObj.response==FLAG_REBELLION_CUST)
        {
          context.proxyResponse.content = getAuthenticatedUserDetail(FLAG_REBELLION_CUST, iam_profile_asJSON, iam_access_token);
        }
        
      }
      
   
      
    }
  }
  catch(err)
  {
    context.proxyResponse.content.asJSON.error = err;
  }