var url = 'https://66.94.14.141/oauth2/v1/token';
var auth_code = request.queryParams['code'];
var redirect_uri = request.queryParams['redirect_uri'];

var headers = {'Content-Type': 'application/x-www-form-urlencoded', 'Authorization' : 'Basic QS1PQy1fbHBxU09yXzpQNTdxRHdUTGVo'};
//var bodyObj = {'code':auth_code, 'grant_type':'authorization_code', 'redirect_uri' : 'https://172.28.96.11:444/#/auth'};

//context.setVariable("headers", headers);

//var body = 'redirect_uri=https://172.28.96.11:444/#/auth&grant_type=authorization_code&code=' + auth_code;
var body = 'redirect_uri=' + redirect_uri + '&grant_type=authorization_code&code=' + auth_code;

//var test_bodyObj = serializeQuery(bodyObj);
//context.setVariable("bodyObj", test_bodyObj);

//response.content = body;

var myRequest = new Request(url,"POST", headers, body);

var req = httpClient.send(myRequest);

req.waitForComplete();
var response = req.getResponse();
context.setVariable("responseVar", response);

if(response && response.status && response.status == 200) {
  
   
   context.setVariable("response.status", response.status);
   
  var result = response;
   var iam_access_token = response.content.asJSON.access_token;
  
   //context.setVariable("result", response.content);
   //context.setVariable("result", result);
   context.setVariable('oauth_external_authorization_status',true);
   context.setVariable('iam_access_token',iam_access_token);
}
else {
 context.setVariable("errorToast", "gets in else"); 
}
