var result = [{"date": "1/1/2015","amount": 84.15,"type": "cash"},{"date": "2/1/2015","amount": 90,"type": "credit"}];

context.proxyResponse.content = JSON.stringify(result);