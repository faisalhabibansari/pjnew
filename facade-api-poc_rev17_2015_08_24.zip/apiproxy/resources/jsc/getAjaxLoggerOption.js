// response.content = '{ "batchSize": 0, "bufferSize": 0, "disallow": "", "ipRegex": "", "level": "VERBOSE", "sendWithBufferLevel": 6000, "storeInBufferLevel": 1000, "userAgentRegex": "", "url": "http://t-mobile-test.apigee.net/facade-api-poc/logs" }'; 

context.setVariable("objectId", "001");
context.setVariable("dataType", "logConfigs");