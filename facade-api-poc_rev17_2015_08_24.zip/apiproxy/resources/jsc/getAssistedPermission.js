/*
Purpose: Script with to retrieve permission related objects from BaaS based and then generate permissionsObject for assisted channel.

Developer: Faisal.Ansari@T-Mobile.com

Revisions:


24 April 2015 | Documentation headers added
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var RESP_SUCCESS = 'SUCCESS';

var OBJ_DATA_TYPE_LINE_ROLE = 'lineRole';
var OBJ_DATA_TYPE_ROLE_ENTITLEMENT = 'roleEntitlement';
var OBJ_DATA_TYPE_ROLE_ROUTE = 'roleRoute';
var OBJ_DATA_TYPE_ELEMENT_PERMISSION = 'elementPermission';
var OBJ_DATA_TYPE_USER_LINE = 'userLine';
var OBJ_DATA_TYPE_ROUTE_OVERRIDE = 'routeOverride';

var processResp = RESP_SUCCESS;
var processRespErr = {};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



var uid=context.getVariable("userId");

var userLines = fnSelectObjectFromBaaS(uid, OBJ_DATA_TYPE_USER_LINE);

var lineArray =userLines[uid];

var roles =[];

  if(lineArray instanceof Array)
  {
   for(var i=0;i<lineArray.length;i++)
      {
          var line = lineArray[i];
  
          //call LineRole for the msisdn
          var lineRoles = fnSelectObjectFromBaaS(line, OBJ_DATA_TYPE_LINE_ROLE);
           if(lineRoles[line] instanceof Array)
           {
            for(var j=0;j<lineRoles[line].length;j++)
            {
                 roles.push(lineRoles[line][j])
            } 
           }
      }
  }

var uniqueRoles = ArrNoDupe(roles);

var routs =[];

var entitlements = [];

    if(uniqueRoles instanceof Array)
    {
     for(var i=0;i<uniqueRoles.length;i++)
      {
          var role = uniqueRoles[i];
  
         //call RoleRoute for the role
         var roleRout = fnSelectObjectFromBaaS(role, OBJ_DATA_TYPE_ROLE_ROUTE);
         if(roleRout[role].enabledRoutes instanceof Array)
         {
           for(var j=0;j<roleRout[role].enabledRoutes.length;j++)
            {
                 routs.push(roleRout[role].enabledRoutes[j])
            }
         }
         //call RoleEntitlements for the role
          var roleEntitlements = fnSelectObjectFromBaaS(role, OBJ_DATA_TYPE_ROLE_ENTITLEMENT);
        
          if(roleEntitlements[role] instanceof Array)
          {
           for(var j=0;j<roleEntitlements[role].length;j++)
            {
                 entitlements.push(roleEntitlements[role][j])
            }
          }
      }
    }




var uniqueRout = ArrNoDupe(routs);

var uniqueEntitlements = ArrNoDupe(entitlements);

 var elementObj ={};


   for(var i=0;i<uniqueRout.length;i++)
      {
         var rout = uniqueRout[i];
        
         //call ElementPermission for the route
         var routElement = fnSelectObjectFromBaaS(rout, OBJ_DATA_TYPE_ELEMENT_PERMISSION);
        
          var routeOverride = fnSelectObjectFromBaaS(rout, OBJ_DATA_TYPE_ROUTE_OVERRIDE);    
        
            var addEntitlement = {};
            var removeEntitlement = {};
        
             if(routeOverride["override"] instanceof Array)
              {
                 for (var x=0;x<routeOverride["override"].length;x++)
                {
                 var k ='';
                 for (var key in routeOverride["override"][x]) 
                 {
                    k =key;
                 }
                 if(routeOverride["override"][x][k].addEntitlement!="")
                 {
                  addEntitlement[k]=routeOverride["override"][x][k].addEntitlement;
                 }
                 if(routeOverride["override"][x][k].removeEntitlement!="")
                 {
                  removeEntitlement[k]=routeOverride["override"][x][k].removeEntitlement;
                 }
                }
              }
      
        var r ={};
        
        if(routElement[rout] instanceof Array)
        {
           for(var j=0;j<routElement[rout].length;j++)
            {
                 var k ='';
                 for (var key in routElement[rout][j]) 
                 {
                    k =key;
                 }
              
              var entitlementArray = [];
              entitlementArray = uniqueEntitlements;
              if(addEntitlement[k]!="")
              {
               entitlementArray.push(addEntitlement[k]); 
              }
              
                for (var x=0;x<entitlementArray.length;x++)
                   {
                    if((entitlementArray[x]==routElement[rout][j][k].entitlement)&&(entitlementArray[x]!=removeEntitlement[k]))
                    {
                       r[k] = routElement[rout][j][k].defaultControl;
                      break;
                    }
                   }
            }

           elementObj[rout] = r;
        }
      }

//Creation permission object
var permissionObject ={'user' : {"userId" : parseInt(uid)}, 'permissions':{'roles':{'users' : uniqueRoles},'iuElements':{'user':{}}}};

permissionObject.permissions.iuElements.user=elementObj;


context.proxyResponse.content = JSON.stringify(permissionObject); 