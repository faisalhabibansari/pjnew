
function getAuthenticatedUserDetail_OLD(FLAG_REBELLION_CUST, iamProfile, iamAccessToken)
{
  
  var iam_profile = iamProfile;
  
  var iam_access_token = iamAccessToken;
  
  var responseBody = {};
  
  responseBody.response = FLAG_REBELLION_CUST;
  
  responseBody.profile = iam_profile;
  
  responseBody.iam_access_token = iam_access_token;
  
  //responseBody.facade_access_token = authResponseCont.access_token;    
  
  var s = JSON.stringify(iam_profile);
  
  context.setVariable("steve_stringify_json", s);
  
  
  var p = JSON.parse(s);
  
  var permObjId = p.TMO_ID_profile.impi1;
  
  context.setVariable("permObjId", permObjId);
  
  var permObj = getPermissions(permObjId);
  
  context.setVariable("permObj", permObj);
  
  responseBody.permissions = permObj;
  
  responseBody.dataCenterSegmentationId = "titan";
  
  
  //response.content = {"response" : "processInRebellion" , "profile" : iam_profile , "iam_access_token" : iam_access_token , "dataCenterSegmentationId" : "titan"}; 
  
  context.setVariable("responseBody", JSON.stringify(responseBody));
  
  
  return responseBody;
}