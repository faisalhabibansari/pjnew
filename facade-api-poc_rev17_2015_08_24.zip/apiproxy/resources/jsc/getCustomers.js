//Grabbing set headers for pass to core services
var headers = context.getVariable('headers');
var customers = [];

//function that will grab json response based on URL passed in
function getCoreJsonResponse(url) {
  var myRequest = new Request(url, 'GET', headers);
  var req = httpClient.send(myRequest);
  req.waitForComplete();
  var response = req.getResponse().content.asJSON;
  
  return response;
}


/*var services = context.getVariable('services');
var url = services.core + '/customer?lastname=smurf&msisdn=012345678911&offset=df&limit=fd';

//var body = request.content.asJSON;
//var req = new Request(url,'GET',{},JSON.stringify(body));
var req = httpClient.get(url); 
req.waitForComplete();

var res = req.getResponse();
var result = res.content.asJSON;

var customers = [];
var customer = {};
customer.ban = 12345678;
customer.name = result[0].party.organization.organizationContact[0].personName[0].fullName;
customer.msdn = result[0].party.organization.organizationContact[0].securityProfile.msisdn;
customer.billingAccount = 'Jane';
customer.device = 'iPhone 5';
customer.balance = 100.00;

customers.push(customer);

//response.status.code = res.status;

context.proxyResponse.content = JSON.stringify(customers); */

/*Using CD 1.1 drop*/

//Setting core URL's to call
try {
  var financialAccountDetailsUrl = 'https://temptmobile-tempdit.apigee.net/v1/financialaccount/124356430?customerid=3000000026';
  var customerDetailsUrl = 'https://temptmobile-tempdit.apigee.net/v1/customer/3000000026';
  
  //Grabbing the JSON response from core service
  var financialAccountResponse = getCoreJsonResponse(financialAccountDetailsUrl);
  var customerDetailsResponse = getCoreJsonResponse(customerDetailsUrl);
  
  //Filling customer object to be returned by facade API
  var customer = {};
  customer.ban = financialAccountResponse.financialAccount.financialAccountNumber;
  customer.name = customerDetailsResponse.customer.party.person[0].personName[0].firstName + ' ' + customerDetailsResponse.customer.party.person[0].personName[0].middleName[0] + ' ' + customerDetailsResponse.customer.party.person[0].personName[0].familyName[0];
  customer.msdn = '+1 312-101-1234';
  customer.billingAccount = customerDetailsResponse.customer.party.person[0].personName[0].firstName;
  customer.device = 'iPhone 5',
  customer.balance = financialAccountResponse.financialAccount.accountBalanceSummaryGroup[0].balanceSummary[0].amount['#text'];
  
  customers.push(customer);
}

catch(err) {
  //context.setVariable("error", "there was an error");
  var customer = {};
  customer.ban = '3000000012';
  customer.name = 'John Michael Brown';
  customer.msdn = '+1 312-101-1234';
  customer.billingAccount = 'John';
  customer.device = 'iPhone 5';
  customer.balance = 100;
  
  customers.push(customer)
}



/* mock start here */
//var services = context.getVariable('services');
//var url = services.core + '/customer?lastname=smurf&msisdn=012345678911&offset=df&limit=fd';

var customerId = context.getVariable('customerId');
//var url = 'http://t-mobile-prod.apigee.net/customer/CUST1234';

/*var req = httpClient.get(url);
req.waitForComplete();
var response = req.getResponse().content.asJSON;
var coreCustomer = response[0];*/

//Using core
/*var phoneFirst3 = coreCustomer.party.person.phoneCommunication[0].phoneNumber.substring(0,3);
var phoneLast4 = coreCustomer.party.person.phoneCommunication[0].phoneNumber.substring(3,7);
customer.name = coreCustomer.party.person.personName.fullName;
customer.msdn = coreCustomer.party.person.phoneCommunication[0].areaCode + '-' + phoneFirst3 + '-' + phoneLast4; //+ '-' + coreCustomer.party.person.phoneCommunication[0].phoneNumber.substring(0,3) + '-' + coreCustomer.party.person.phoneCommunication.phoneNumber[0].substring(3,4);
customer.ban = 12345678;
customer.billingAccount = 'Jane';
customer.device = 'iPhone 5';
customer.balance = 100.00;
customers.push(customer);*/


context.proxyResponse.content = JSON.stringify(customers);/**/