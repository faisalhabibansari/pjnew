/*

  
*/

function fnGetElementPermissions(routeName) {

try { 
	var url = "";
	if((routeName!=null)&&(routeName!='')) {
      context.setVariable('fnGetElementPermissions.trace', routeName);
      url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='elementPermission' and id=" + "'" + routeName + "'";
  	}
  	else {
      	context.setVariable('fnGetElementPermissions.trace', 'return elementPermission for all routes');
    	url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='elementPermission'";
    }
      	
       
    	var headers = {'Content-Type' : 'application/json'};
		var myRequest = new Request(url,"GET",headers);
		var req = httpClient.send(myRequest);

    	//var req = httpClient.get(url);
		req.waitForComplete();
		

        if (req.isSuccess()) {
          
          
          var mData = req.getResponse().content.asJSON;
          return mData;
          
        }
		
  }
  catch(err) {
    context.proxyResponse.content.asJSON.error = err;    
  }

}

////////////////////////////////////////////////////////////////////////////////////////

// Grab the roleName from context
var routeName = context.getVariable("routeName");

var permissionsObj = fnGetElementPermissions(routeName);
context.setVariable('getElementPermissions.routeName', routeName);

if(permissionsObj!=null){
var permissionsList = permissionsObj.entities;
context.setVariable('permissionsList.length', permissionsList.length);
if((routeName==null)||(routeName=='')&&(permissionsList.length>=1)) {
  //var mObj = [];
  var mObj = {};
  for(mLen=0;mLen<permissionsList.length;mLen++) {
    var b = JSON.stringify(permissionsList[mLen].mockData);   
    var bObj = JSON.parse(b);
    var bObjRoleName = Object.keys(bObj)[0];
    mObj[bObjRoleName]=bObj[bObjRoleName];
    //mObj[mLen]=routeList[mLen].mockData;	
  }
   context.setVariable('mObj.length', mObj.length);
  context.proxyResponse.content = JSON.stringify(mObj);
}
else if((routeName!=null)&&(routeName!='')&&(permissionsList.length==1)) {  
  var mockResp = JSON.stringify(permissionsList[0].mockData);  
  context.setVariable('permissionsList[0].mockData', mockResp);
  context.proxyResponse.content = mockResp;
}
}