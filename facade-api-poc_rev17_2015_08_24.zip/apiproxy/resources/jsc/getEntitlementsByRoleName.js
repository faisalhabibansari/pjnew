/*

Script: getEntitlementsByRoleName.js

  
*/

function fnGetEntitlements(roleName) {

try { 
	var url = "";	
  if((roleName!=null)&&(roleName!='')) {
      context.setVariable('fnGetEntitlements.trace', roleName);
      url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='roleEntitlement' and id=" + "'" + roleName + "'";
  	}
  	else {
      	context.setVariable('fnGetEntitlements.trace', 'return entitlement list for all roles');
    	url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='roleEntitlement'";
    }
 		
    
       
    	var headers = {'Content-Type' : 'application/json'};
		var myRequest = new Request(url,"GET",headers);
		var req = httpClient.send(myRequest);

    	
		req.waitForComplete();
		

        if (req.isSuccess()) {
          
        
          var mData = req.getResponse().content.asJSON;
          return mData;
   
        }
		
  }
  catch(err) {
    context.proxyResponse.content.asJSON.error = err;    
  }

}

