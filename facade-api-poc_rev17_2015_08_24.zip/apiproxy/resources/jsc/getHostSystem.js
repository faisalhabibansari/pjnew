function fnGetHostSystem(usrMsisdn)
{
  var msisdn = usrMsisdn;
  
  var hostSysStr = '';
  
  var hostSystemRespMockObj = {};
  
  var url = 'https://t-mobile-test.apigee.net/tmo/v1/getHostSystem?msisdn=' + usrMsisdn;
  context.setVariable('authenticate.user.fnGetHostSystem', url);
  
  var headers = {'Content-Type' : 'application/json'};
  
  try
  {
    
  
    var myRequest = new Request(url,"GET",headers);
    
    var req = httpClient.send(myRequest);
    
    req.waitForComplete();
    
    var response = req.getResponse();
    
    context.setVariable("responseresponse", response);
    
    
    
    if((response!=null) && (response.status == 200)) {

      var hostSystemRespMockObj = response.content.trim().asJSON;

      context.setVariable('hostSystemRespMockObj', JSON.stringify(hostSystemRespMockObj));
      
       return hostSystemRespMockObj;
    }
    
   
  }
  catch(err)
  {
    context.proxyResponse.content.asJSON.error = err;
  }
}