//response.content = '{ "enabled": "true", "maxMessages": "no" } ';

context.setVariable("objectId", "002");
context.setVariable("dataType", "logConfigs");