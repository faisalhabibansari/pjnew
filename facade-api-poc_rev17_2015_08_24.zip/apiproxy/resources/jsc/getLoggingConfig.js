/*

*/

var lgSetting = context.getVariable('logSetting');

var queryStr = "?ql=select * where dataType='logConfigs' and id= '002'";

var url = lgSetting.baas.url + queryStr;


var req = httpClient.get(url);

req.waitForComplete();

if(req.isSuccess())
{    
  var loggingConfigs = req.getResponse().content.asJSON.entities[0];
  context.setVariable('glbLoggingConfig', loggingConfigs);
  context.setVariable('glbLoggingConfigRefreshed',true);
}