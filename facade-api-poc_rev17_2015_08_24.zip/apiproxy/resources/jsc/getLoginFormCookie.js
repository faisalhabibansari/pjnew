

var baseUrl = 'https://DEVRBLCMSOR21D-ELB-1031444497.us-west-2.elb.amazonaws.com:4445';
var url = baseUrl + '/index.html';

//var url = 'https://www.google.com/';

var headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': '',
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

var myRequest = new Request(url, "GET", headers);

var req = httpClient.send(myRequest);

req.waitForComplete();

var reqResponse = req.getResponse();

// process response

if (reqResponse && reqResponse.headers) {

    var cookieString = JSON.stringify(reqResponse.headers['Set-Cookie']);

    var cookieParts = cookieString.split(';');

    var cookies = [];

    for (k in cookieParts) {
        if (cookieParts.hasOwnProperty(k)) {
            if (cookieParts[k].indexOf('httponly') < 0) {
                if (cookieParts[k].indexOf('path=') < 0) {
                    if (cookieParts[k].indexOf('domain=') < 0) {
                        if (cookieParts[k].indexOf('secure') < 0) {
                            if (cookieParts[k] && cookieParts[k] != '') {
                                cookies.push(cookieParts[k].replace('"', ''));
                            }
                        }
                    }
                }
            }
        }
    }

    // add cookieString to context
    cookieString = cookies.join(';');
    context.setVariable('cookieString', cookieString);

    // add Location to context
    var locationString = reqResponse.headers.Location;
    context.setVariable('formLocation', locationString);

    // set url 
    var url2 = baseUrl + locationString;

    // set headers

    var headers2 = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Connection': 'keep-alive',
        'Cookie': cookieString,
        'Accept-Encoding': 'gzip, deflate, sdch',
        'Accept-Language': 'en-US,en;q=0.8',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
    };

    // make request

    var myRequest2 = new Request(url2, "GET", headers2);

    var req2 = httpClient.send(myRequest2);

    req2.waitForComplete();

    var reqResponse2 = req2.getResponse();

    // process response2

    var cookieString2 = JSON.stringify(reqResponse2.headers['Set-Cookie']);

    var cookieParts2 = cookieString2.split(';');

    var cookies2 = [];

    for (k in cookieParts2) {
        if (cookieParts2.hasOwnProperty(k)) {
            if (cookieParts2[k].indexOf('httponly') < 0) {
                if (cookieParts2[k].indexOf('path=') < 0) {
                    if (cookieParts2[k].indexOf('domain=') < 0) {
                        if (cookieParts2[k].indexOf('secure') < 0) {
                            if (cookieParts2[k] && cookieParts2[k] != '') {
                                cookies2.push(cookieParts2[k].replace('"', ''));
                            }
                        }
                    }
                }
            }
        }
    }

    // add cookieString to context
    cookieString2 = cookies2.join(';');
    context.setVariable('cookieString2', cookieString2);

    // diagnostic output
    // response.content = JSON.stringify(["output>> ", reqResponse, "cookieString>> ", cookieString, "locationString>> ", locationString, "cookieString2>> ", cookieString2]);

}