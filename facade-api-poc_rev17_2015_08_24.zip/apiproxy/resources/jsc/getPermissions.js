function getPermissions(objId)
{
  var headers = {'Content-Type' : 'application/json'};
  
  var permUrl = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='userPermissions' and id='" + objId + "'";
  context.setVariable("authenticate.user.getPermissions.permUrl", permUrl);
  
  try
  {
    
    var myRequest = new Request(permUrl,"GET",headers);
    
    var req = httpClient.send(myRequest); 
    
    req.waitForComplete();
    
    var resp = req.getResponse().content.asJSON;
    
    var response = resp.entities[0].mockData;
    
    return response;
   }
    catch(err)
    {
      context.proxyResponse.content.asJSON.error = err;
    }
}