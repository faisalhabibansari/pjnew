var iam_access_token = context.getVariable('iam_access_token');
  
  var url = 'https://66.94.14.141/userprofile/p/v1/userinfo';
  
  //var msisdn = context.proxyRequest.queryParams['msisdn'];
  //var iam_token = context.getVariable('iam_access_token');
  
  var bearer = "Bearer " + iam_access_token;
  context.setVariable("Bearer", bearer);
  
  var headers = {"Authorization": "Bearer " + iam_access_token};
  
  
  var myRequest = new Request(url,"GET",headers);
  var req = httpClient.send(myRequest);
  
  req.waitForComplete();
  var response = req.getResponse();
	
  //context.setVariable("response", response);
  
  if(response.status == 200) {
     var iam_profile = response.content.asJSON;
     context.setVariable("iam_profile", iam_profile);
    //var iam_profile = profileResult;
     //context.setVariable("msisdn", context.getVariable("iam_profile").profile.associated_lines.line[0].MSISDN);
     msisdn = iam_profile.associated_lines.lines[0].MSISDN;
    context.setVariable('msisdn', msisdn);
      
    //Mocking get host
      if(msisdn == "5157710112") {
      context.proxyResponse.content = '{"response" : "redirectToEService", "BAN":"12312", "MSISDN": "5157710112"}';
    } else {
        var responseBody = {};
        responseBody.response = "processInRebellion";
        responseBody.profile = iam_profile;
        responseBody.iam_access_token = iam_access_token;
        responseBody.dataCenterSegmentationId = "titan";
        //response.content = {"response" : "processInRebellion" , "profile" : iam_profile , "iam_access_token" : iam_access_token , "dataCenterSegmentationId" : "titan"}; 
        
      context.setVariable("responseBody", JSON.stringify(responseBody));
      context.proxyResponse.content = JSON.stringify(responseBody);
    } 
  }


/*var url = 'https://66.94.14.141/userprofile/p/v1/userinfo';

//var msisdn = context.proxyRequest.queryParams['msisdn'];
var iam_token = context.getVariable('iam_access_token');

var bearer = "Bearer " + iam_token;
context.setVariable("Bearer", bearer);

var headers = {"Authorization": "Bearer " + iam_token};


var myRequest = new Request(url,"GET",headers);
var req = httpClient.send(myRequest);

req.waitForComplete();
var response = req.getResponse();

if(response.status == 200) {
   var result = response.content;
   context.setVariable("iam_profile", result);
   context.setVariable("msisdn", context.getVariable("iam_profile").profile.associated_lines.line[0].MSISDN);
   
  	//Mocking get host
    if(context.getVariable("MSISDN") == "tel:+19392161519") {
    response.content = {"response" : "redirectToEService", "BAN":"12312", "MSISDN": "9392161519"};
  } else {
    
    response.content = '{"response" : "processInRebellion" , "profile": "'+ context.getVariable("iam_profile").asJSON +'" , "iam_access_token" : "' + context.getVariable("access_token") +'" , "dataCenterSegmentationId" : "titan"}'; 
  } 
}*/