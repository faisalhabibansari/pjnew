// Grab the roleName from context
var roleName = context.getVariable("roleName");

var entitlementObj = fnGetEntitlements(roleName);

context.setVariable('getRoleEntitlements.roleName', roleName);

if(entitlementObj!=null){

	var entitlementList = entitlementObj.entities;
	
	context.setVariable('entitlementList.length', entitlementList.length);

	if((roleName==null)||(roleName=='')&&(entitlementList.length>=1)) 
	{
      	var mObj = {};
      
		for(mLen=0;mLen<entitlementList.length;mLen++) {

		    var b = JSON.stringify(entitlementList[mLen].mockData);
		    
		    var bObj = JSON.parse(b);
		    
		    var bObjRoleName = Object.keys(bObj)[0];
		    
		    mObj[bObjRoleName]=bObj[bObjRoleName];
		    
		  }
		  
		  context.setVariable('mObj.length', mObj.length);
		  context.proxyResponse.content = JSON.stringify(mObj);

	}
	else if((roleName!=null)&&(roleName!='')&&(entitlementList.length==1))
	{  
        var mockResp = JSON.stringify(entitlementList[0].mockData);

	  context.setVariable('entitlementList[0].mockData', mockResp);

          context.proxyResponse.content = mockResp;
	}
}