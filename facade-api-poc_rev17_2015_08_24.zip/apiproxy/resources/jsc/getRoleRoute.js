// Grab the roleName from context
var roleName = context.getVariable("roleName");

var routeObj = fnGetRoutes(roleName);
context.setVariable('getRoleRoute.roleName', roleName);

if(routeObj!=null){
var routeList = routeObj.entities;
context.setVariable('routeList.length', routeList.length);
if((roleName==null)||(roleName=='')&&(routeList.length>=1)) {
  //var mObj = [];
  var mObj = {};
  for(mLen=0;mLen<routeList.length;mLen++) {
    var b = JSON.stringify(routeList[mLen].mockData);
    var bObj = JSON.parse(b);
    var bObjRoleName = Object.keys(bObj)[0];
    mObj[bObjRoleName]=bObj[bObjRoleName];
    //mObj[mLen]=routeList[mLen].mockData;	
  }
   context.setVariable('mObj.length', mObj.length);
  context.proxyResponse.content = JSON.stringify(mObj);
}
else if((roleName!=null)&&(roleName!='')&&(routeList.length==1)) {  
  context.setVariable('routeList[0].mockData', JSON.stringify(routeList[0].mockData));
  context.proxyResponse.content = JSON.stringify(routeList[0].mockData);
}
}