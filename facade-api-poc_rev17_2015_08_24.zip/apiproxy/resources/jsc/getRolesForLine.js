/*

Purpose: Script to retrieve Roles for a given line from BaaS.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:

7 April 2015 | Added Documentation Headers
  
*/

function fnSelectRolesForLine(lineId) {

try { 
	var url = "";
	if((lineId!=null)&&(lineId!='')) {
      context.setVariable('fnGetRoles.trace', lineId);
      url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='lineRole' and id=" + "'" + lineId + "'";
  	}
  	else {
      	context.setVariable('fnGetRoles.trace', 'return role list for all lines');
    	url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='lineRole'";
    }
      	
       
    	var headers = {'Content-Type' : 'application/json'};
		var myRequest = new Request(url,"GET",headers);
		var req = httpClient.send(myRequest);

    	
		req.waitForComplete();
		

        if (req.isSuccess()) {
          
          
          var mData = req.getResponse().content.asJSON;
          return mData;
          
        }
		
  }
  catch(err) {
    context.proxyResponse.content.asJSON.error = err;    
  }

}


function fnGetRolesForLine(lineId)
{
  var lineObj = fnSelectRolesForLine(lineId);
  context.setVariable('fnGetRolesForLine.lineId', lineId);
  
  if(lineObj!=null)
  {
  	var lineList = lineObj.entities;
    
  	context.setVariable('lineList.length', lineList.length);
    
    if((lineId==null)||(lineId=='')&&(lineList.length>=1)) {
      //var mObj = [];
      var mObj = {};
      
      for(mLen=0;mLen<lineList.length;mLen++) 
      {
        var b = JSON.stringify(lineList[mLen].mockData);
        var bObj = JSON.parse(b);
        var bObjLineId = Object.keys(bObj)[0];
        mObj[bObjLineId]=bObj[bObjLineId];
        //mObj[mLen]=routeList[mLen].mockData;	
      }
       	
      	context.setVariable('mObj.length', mObj.length);
      	context.proxyResponse.content = JSON.stringify(mObj);
    }
    else if((lineId!=null)&&(lineId!='')&&(lineList.length==1)) 
    {  
      context.setVariable('lineList[0].mockData', JSON.stringify(lineList[0].mockData));
      context.proxyResponse.content = JSON.stringify(lineList[0].mockData);
    }
  }
 
}

// Grab the roleName from context
var lineId = context.getVariable("lineId");


fnGetRolesForLine(lineId);