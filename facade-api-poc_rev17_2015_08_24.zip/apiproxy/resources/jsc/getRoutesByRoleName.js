/*

Purpose: Script to retrieve Routes for a given role from BaaS.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:

7 April 2015 | Added Documentation Headers
  
*/

function fnGetRoutes(roleName) {

try {
  
	var url = "";
	if((roleName!=null)&&(roleName!='')) 
    {
      context.setVariable('getRoutesByRoleName.trace', roleName);
      url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='roleRoute' and id=" + "'" + roleName + "'";
  	}
  	else {
      	context.setVariable('getRoutesByRoleName.trace', 'return route list for all roles');
    	url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType='roleRoute'";
    }
      	
       
    	var headers = {'Content-Type' : 'application/json'};
		var myRequest = new Request(url,"GET",headers);
		var req = httpClient.send(myRequest);

    	
		req.waitForComplete();
		

        if (req.isSuccess()) {
          
          
          var mData = req.getResponse().content.asJSON;
          return mData;
          
        }
		
  }
  catch(err) {
    context.proxyResponse.content.asJSON.error = err;    
  }

}