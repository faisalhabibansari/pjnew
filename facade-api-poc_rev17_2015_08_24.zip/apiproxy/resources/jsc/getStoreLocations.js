//Grab query parameters
/*var addressLine = context.proxyRequest.queryParams['AddressLine'];
var primaryCity = context.proxyRequest.queryParams['PrimaryCity'];
var secondaryCity = context.proxyRequest.queryParams['SecondaryCity'];
var subdivision = context.proxyRequest.queryParams['Subdivision'];
var postalCode = context.proxyRequest.queryParams['PostalCode'];
var countryRegion = context.proxyRequest.queryParams['CountryRegion'];
var formattedAddress = context.proxyRequest.queryParams['FormattedAddress'];
var latitude = context.proxyRequest.queryParams['Latitude'];
var longitude = context.proxyRequest.queryParams['Longitude'];
var distance = context.proxyRequest.queryParams['Distance'];
var startIndex = context.proxyRequest.queryParams['StartIndex'];
var count = context.proxyRequest.queryParams['Count'];
var wfm = context.proxyRequest.queryParams['WFM'];*/

//Grab query parameters
var queryList = context.proxyRequest.queryParams;

context.setVariable('queryList', queryList);

var query = context.proxyRequest.queryParams['query'];
var latitude = context.proxyRequest.queryParams['latitude'];
var longitude = context.proxyRequest.queryParams['longitude'];
var count = context.proxyRequest.queryParams['count'];
var distance = context.proxyRequest.queryParams['distance'];
var startIndex = context.proxyRequest.queryParams['start'];

// For zoom values
var zoomlevel = context.proxyRequest.queryParams['zoomlevel'];
var latends = context.proxyRequest.queryParams['latends'];
var latstarts = context.proxyRequest.queryParams['latstarts'];
var lngends = context.proxyRequest.queryParams['lngends'];
var lngstarts = context.proxyRequest.queryParams['lngstarts'];


var lengthTest = latitude.length;

context.setVariable('lat', latitude);
context.setVariable('lat_length', lengthTest);


if ('latitude' in queryList) {
 context.setVariable('test', 'gets here'); 
}

if('zoomlevel' in queryList){
  var url = 'http://www.t-mobile.com/srvspub/storelocsearch?count='+count+'&latcentre='+latitude+'&latends='+latends+'&latstarts='+latstarts+'&lngcentre='+longitude+'&lngends='+lngends+'&lngstarts='+lngstarts+'&query='+query+'&start='+startIndex+'&zoomlevel='+zoomlevel;
}

else if ('latitude' in queryList && 'longitude' in queryList && 'query' in queryList) {
	//Build callout URL for when latitude and longitude are not present
  	var url = 'http://www.t-mobile.com/srvspub/storelocsearch?count=' + count + '&dist=' + distance + '&latcentre=' + latitude + '&lngcentre=' + longitude + '&query=' + query + '&start=' + startIndex;
	
}
//Build callout URL
else if ('query' in queryList) {
	var url = 'http://www.t-mobile.com/srvspub/storelocsearch?count=' + count + '&dist=' + distance + '&query=' + query + '&start=' + startIndex;
}

else {
  var url = 'http://www.t-mobile.com/srvspub/storelocsearch?count=' + count + '&dist=' + distance + '&latcentre=' + latitude + '&lngcentre=' + longitude + '&start=' + startIndex;
}

context.setVariable('url', url);

//HTTP Request
var req = httpClient.get(url);
req.waitForComplete();
var response = req.getResponse();
var storeLocationData = response.content.asJSON;

context.setVariable("storeLocationData response", JSON.stringify(storeLocationData));


var facadeResponse = {"startIndex":"",
"numberfound" : "",
"stores":[]
};

//var store = {};

facadeResponse.startIndex = storeLocationData.startIndex;
facadeResponse.numberfound = storeLocationData.numberfound;

var numberOfStores = storeLocationData.stores.length;
context.setVariable("numberOfStores", numberOfStores);
for (k = 0; k < numberOfStores; k++) {

                    var storeId = storeLocationData.stores[k].locationID;
                    var store = storeLocationData.stores[k];
                    var AEMURL = 'http://webdev1aempublish.rebellion.t-mobile.com:4503/bin/tmo/service/storedescription.' + storeId +'.json';
  					context.setVariable('AEMurl', AEMURL);

			var req1 = httpClient.get(AEMURL);
			req1.waitForComplete();
			var AEMresponse = req1.getResponse();
  //context.setVariable("AEMresponse", JSON.stringify(AEMresponse));
  context.setVariable("AEMresponse", AEMresponse);
  var AEMresponseStatus = req1.getResponse().status;
            context.setVariable("responseStatus", AEMresponseStatus);
  
            var AEMresponseJSON = AEMresponse.content.asJSON;
            //context.setVariable("AEMresponse", JSON.stringify(AEMresponse));
  			
  /* var headers = {'Content-Type' : 'application/json'};
  var myRequest = new Request(AEMURL,"GET",headers);
  var req1 = httpClient.send(myRequest);

    req1.waitForComplete();
  	
	var mData = req1.getResponse().content.asJSON;	*/	
			//store.generic = mData.generic;
          // facadeResponse.stores.push(store);
 
  facadeResponse.stores.push({"description":AEMresponseJSON.storeId,"generic":AEMresponseJSON.generic,});
                }


//Proxying through to our response
context.proxyResponse.content = JSON.stringify(facadeResponse);
  
  
