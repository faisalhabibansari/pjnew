var services = context.getVariable('services');
var macAddress = context.proxyRequest.queryParams['macAddress']
//var url = services.core + '/terminal?macaddress=' + macAddress;
var url = 'http://t-mobile-prod.apigee.net/terminal?macaddress=' + macAddress;

var req = httpClient.get(url);
req.waitForComplete(4000);
context.proxyResponse.content = req.getResponse().content;


//context.proxyResponse.content = url;
