/*var applicationStateKey=context.getVariable("request.queryparam.applicationStateKey");
context.setVariable("dataType","applicationState");

if(applicationStateKey!=null)
{
  context.setVariable("objectId",applicationStateKey);
}

var response = {
    "editButton": "enabled"
};

context.proxyResponse.content = JSON.stringify(response);*/

/////////////////////////////////////////////////////////////////////

var headers = context.getVariable("headers");
var applicationStateKey = context.proxyRequest.queryParams['applicationStateKey'];
context.setVariable('applicationStateKey', applicationStateKey);


var url = 'https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType=' + "'applicationState'" + 'and id=' + "'" + applicationStateKey +"'";
context.setVariable("urlis", url);

var myRequest = new Request(url,"GET",headers);
var req = httpClient.send(myRequest);
req.waitForComplete();

var res1 = req.getResponse().content.asJSON;

if(res1.entities[0]!= null){
 var res = req.getResponse().content.asJSON.entities[0].mockData;
 context.proxyResponse.content = JSON.stringify(res);
	   
};
