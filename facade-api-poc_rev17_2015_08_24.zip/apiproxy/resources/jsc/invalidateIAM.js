var url = "https://{host}:{port}/oauth2-api/p/v1/signout";

var body = {
  "user_id":"",
  "is_global":""
};

var headers = {
  "Authorization":"Bearer Access_Token",
  "Content-Type":"application/json",
  "Accept":"application/json"
};

try
{	
	var myRequest = new Request(url, "POST", headers, body);
	var req = httpClient.send(myRequest);
	    
	req.waitForComplete();
	var response = req.getResponse();     
}
catch(err)
{
	context.setVariable("IAM.logout.err", err);
}