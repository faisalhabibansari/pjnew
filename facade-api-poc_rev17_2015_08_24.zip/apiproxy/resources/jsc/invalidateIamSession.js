var url = 'https://66.94.14.141/oauth2-api/p/v1/signout';
var headers = {'Content-Type': 'application/json', 'Accept' : 'application/json', 'Authorization' : 'Basic QS1PQy1fbHBxU09yXzpQNTdxRHdUTGVo'};
var body = "{ 'user_id': 'uid:" + context.getVariable('userId') + "', 'is_global': 'yes' }"

try
{
	
	var myRequest = new Request(url, "POST", headers, body);
	var req = httpClient.send(myRequest);
	req.waitForComplete();
	var response = req.getResponse();
    context.setVariable("iam.response.text", response);
  
	/*
  	if (response.status == 200) {
    } else {
      context.setVariable("steve.err", err);
    }
    */
}
catch(err)
{
	context.setVariable("iam.response.error", err);
}
