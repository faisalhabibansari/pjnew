var url = "https://api.usergrid.com/louis.lim5/sandbox/logs";
var myRequest = new Request(url,"POST", {}, JSON.stringify(request.content.asJSON));
var req = httpClient.send(myRequest);