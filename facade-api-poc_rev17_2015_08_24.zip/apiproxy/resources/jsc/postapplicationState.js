var facadeRequest = JSON.parse(context.getVariable('request.content'));
var OBJ_DATA_TYPE='applicationState';
var applicationStateKey = facadeRequest.applicationStateKey;
var reqContent = facadeRequest.value;

context.setVariable('Id', applicationStateKey);
 
var headers = {'Content-Type' : 'application/json'};

//Get data
var url = 'https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType=' + "'applicationState'" + 'and id=' + "'" + applicationStateKey +"'";

var myRequest = new Request(url,"GET",headers);
var req = httpClient.send(myRequest);
req.waitForComplete();

var res = req.getResponse().content.asJSON;

context.setVariable("responseis", res);
 

if(res.entities[0]!= null && res.entities[0].mockData!= null){
  var uuid = req.getResponse().content.asJSON.uuid;
   context.setVariable('uuid is', uuid);
  var url2 = 'https://api.usergrid.com/louis.lim5/sandbox/mocks/' + uuid;
  context.setVariable('deleteurls is', url2);
 //Delete data
  var myRequest = new Request(url,"DELETE",headers);
var req = httpClient.send(myRequest);
req.waitForComplete();
    
  //Post data
var coreRequest = {
    "dataType": "applicationState",
    "id": "",
    "mockData": ''};

  coreRequest.id = applicationStateKey;
  coreRequest.mockData = reqContent;


var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks";

var myRequest = new Request(url,"POST",headers,JSON.stringify(coreRequest));
var req = httpClient.send(myRequest);

  req.waitForComplete();
  
  if (req.isSuccess()) {
    //
    context.setVariable('req.isSuccess()', req.isSuccess());
  }
	   
}else{

//Post data
var coreRequest = {
    "dataType": "applicationState",
    "id": "",
    "mockData": ''};

  coreRequest.id = applicationStateKey;
  coreRequest.mockData = reqContent;


var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks";

var myRequest = new Request(url,"POST",headers,JSON.stringify(coreRequest));
var req = httpClient.send(myRequest);

  req.waitForComplete();
  
  if (req.isSuccess()) {
    //
    context.setVariable('req.isSuccess()', req.isSuccess());
  }
}
