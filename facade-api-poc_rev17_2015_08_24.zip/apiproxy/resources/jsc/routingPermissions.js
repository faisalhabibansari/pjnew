/*
Purpose: Script with to retrieve permission related objects from BaaS based and then generate permissionsObject.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:


8 April 2015 | Documentation headers added
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
var RESP_SUCCESS = 'SUCCESS';

var OBJ_DATA_TYPE_LINE_ROLE = 'lineRole';
var OBJ_DATA_TYPE_ROLE_ENTITLEMENT = 'roleEntitlement';
var OBJ_DATA_TYPE_ROLE_ROUTE = 'roleRoute';
var OBJ_DATA_TYPE_ELEMENT_PERMISSION = 'elementPermission';
var OBJ_DATA_TYPE_USER_LINE = 'userLine';

var processResp = RESP_SUCCESS;
var processRespErr = {};

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


var uid=context.getVariable("userId");

var userLines = fnSelectObjectFromBaaS(uid, OBJ_DATA_TYPE_USER_LINE);

var lineArray =userLines[uid];

var lineAndItsRole = {};

   if(lineArray instanceof Array)
  {
   for(var i=0;i<lineArray.length;i++)
      {
          var line = lineArray[i];
        
          var lineRoleArray =[];
  
          //call getLineRoles API for the msisdn
          var lineRoles = fnSelectObjectFromBaaS(line, OBJ_DATA_TYPE_LINE_ROLE);
        
        if(lineRoles[line] instanceof Array)
        {
           for(var j=0;j<lineRoles[line].length;j++)
            {
               lineRoleArray.push(lineRoles[line][j]);
            }
          lineAndItsRole[line]=lineRoleArray; 
        }
      }
  }


var lineAndItsRout = {};

var lineAndItsEntitlement = {};


for(var line in lineAndItsRole)
    {
      var lineRoutArray =[];
      if(lineAndItsRole[line] instanceof Array)
      {
       for(var a=0;a<lineAndItsRole[line].length;a++)
        {
           var role = lineAndItsRole[line][0];
  
          var roleRout = fnSelectObjectFromBaaS(role, OBJ_DATA_TYPE_ROLE_ROUTE);
        
           if(roleRout[role].enabledRoutes instanceof Array)
           {
            for(var j=0;j<roleRout[role].enabledRoutes.length;j++)
            { 
                 lineRoutArray.push(roleRout[role].enabledRoutes[j])
            } 
           }
        
          var roleEntitlementArray = [];
          
          var roleEntitlements = fnSelectObjectFromBaaS(role, OBJ_DATA_TYPE_ROLE_ENTITLEMENT);
        
          if(roleEntitlements[role] instanceof Array)
          {
          for(var j=0;j<roleEntitlements[role].length;j++)
            {
                 roleEntitlementArray.push(roleEntitlements[role][j])
            }
          }
        }
       }
        lineAndItsRout[line]=ArrNoDupe(lineRoutArray);
        lineAndItsEntitlement[line]=ArrNoDupe(roleEntitlementArray);
    }

var elementObj ={};

for(var line in lineAndItsRout)
    {
      var lineObj ={};
       for(var a=0;a<lineAndItsRout[line].length;a++)
      {
         var rout = lineAndItsRout[line][a];
        
         var routElement = fnSelectObjectFromBaaS(rout, OBJ_DATA_TYPE_ELEMENT_PERMISSION);
        
        var elementEntitlement ={};
        
        if(routElement[rout] instanceof Array)
        {
           for(var j=0;j<routElement[rout].length;j++)
            {
                 var k ='';
                 for (var key in routElement[rout][j]) 
                 {
                    k =key;
                 }
              
                for (var x=0;x<lineAndItsEntitlement[line].length;x++)
                   {
                    if(lineAndItsEntitlement[line][x]==routElement[rout][j][k].entitlement)
                    {
                       elementEntitlement[k] = routElement[rout][j][k].defaultControl;
                      break;
                    }
                   }
            }

           lineObj[rout] = elementEntitlement;
        }   
      }  
      elementObj[line] = lineObj;  
    }

var permissionObject ={'user' : {"userId" : parseInt(uid)}, 'permissions':{'roles': lineAndItsRole,'iuElements':{}}};

permissionObject.permissions.iuElements=elementObj;


context.proxyResponse.content = JSON.stringify(permissionObject); 

