/*
Purpose: Script with utility function to retrieve objects from BaaS based on the object id and object type.

Developer: Chandan.Chawla@T-Mobile.com

Revisions:


8 April 2015 | Documentation headers added

*/

function fnSelectObjectFromBaaS(objId, objType) 
{
    var url = "";
  	var mObj = {};
	var mockResp = {};
  	var mData = {};
    
    if((objId!=null)&&(objId!='')&&(objType!=null)&&(objType!=''))
    {
      context.setVariable('fnSelectObjectFromBaaS.objId', objId);
      context.setVariable('fnSelectObjectFromBaaS.objType', objType);

       url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where id='"+objId+"' and dataType='"+objType+"'";
      
      var headers = {'Content-Type' : 'application/json'};
      var myRequest = new Request(url,"GET",headers);
      var req = httpClient.send(myRequest);

      req.waitForComplete();
 
      if (req.isSuccess()) {
        
        var mObj = req.getResponse().content.asJSON;
        
        context.setVariable("fnSelectObjectFromBaaS.mObj",JSON.stringify(mObj));
        
        if(mObj.entities[0]!= null && mObj.entities[0].mockData!= null){
		mData = mObj.entities[0].mockData;
                              
        context.setVariable("fnSelectObjectFromBaaS.mData",JSON.stringify(mData));
        }
                
      }
    }
	return mData;       	
}

function ArrNoDupe(a) {
    var temp = {};
    for (var i = 0; i < a.length; i++)
        temp[a[i]] = true;
    var r = [];
    for (var k in temp)
        r.push(k);
    return r;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*
function fnSelectObjectFromBaaS(objId, objType) 
{

    var url = "";
  	var mObj = {};
	var mockResp = {};
  	var mData = {};
    
    if((objId!=null)&&(objId!='')&&(objType!=null)&&(objType!=''))
    {
      context.setVariable('fnSelectObjectFromBaaS.objId', objId);
      context.setVariable('fnSelectObjectFromBaaS.objType', objType);
      
      url = "https://api.usergrid.com/louis.lim5/sandbox/mocks?ql=select * where dataType=" + "'" + objType + "'" + " and id=" + "'" + objId + "'";
      
      var headers = {'Content-Type' : 'application/json'};
      var myRequest = new Request(url,"GET",headers);
      var req = httpClient.send(myRequest);
      
      
      req.waitForComplete();
      
      
      if (req.isSuccess()) {
        
        
        //var mData = req.getResponse().content.asJSON;
        
        //var mObj = JSON.parse(JSON.stringify(req.getResponse().content));
        
        

        
        var mObj = req.getResponse().content.asJSON;
        
        context.setVariable("fnSelectObjectFromBaaS.mObj",JSON.stringify(mObj));
        
        if(mObj.entities[0]!= null && mObj.entities[0].mockData!= null){
		mData = mObj.entities[0].mockData;
                              
        context.setVariable("fnSelectObjectFromBaaS.mData",JSON.stringify(mData));
        }
                
      }
    }

	return mData;       
    	
		
}
*/
//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

/*function fnValidateEntitlements(roleEntitlements, uiElementRoleEntlment)
{
	var roleEntitlementsObj = roleEntitlements;
	var uiElementRoleEntlmentStr = uiElementRoleEntlment;

	var entitlementArr = roleEntitlementsObj[Object.keys(roleEntitlementsObj)[0]];
	var isEntitlementValid = false;

	for (var i = 0; i < entitlementArr.length; i++) {
		var entlmnt = entitlementArr[i];

		if(entlmnt==uiElementRoleEntlmentStr)
		{
			context.setVariable("rlEnt=",entlmnt);
			isEntitlementValid = true;
		}
		
		
	}
		
	return isEntitlementValid;

}

//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
function fnProcessPermissions(usrId)
{

	var obj = [];
	var userId = usrId;
	
  	
  	var user =  {"userid" : userId};

	var permissions = {
		"roles" : {}
	};

	var roles = {};
	var rolesObj = {};
	var uiElements = {}; 
	var usr ={};
  	var usrObj = {};

  	try
    {
      
      var userMSISDNObj = fnSelectObjectFromBaaS(usrId, OBJ_DATA_TYPE_USER_LINE);
      var userMSISDNs = userMSISDNObj[userId];
      
      //loop through the msisdn array and extract roles for each
      for(var msisdnLen=0;msisdnLen<userMSISDNs.length;msisdnLen++)
      {
          var msisdn = userMSISDNs[msisdnLen];
  
          //call getLineRoles API for the msisdn
          var lineRoles = fnSelectObjectFromBaaS(msisdn, OBJ_DATA_TYPE_LINE_ROLE);
        
          obj[msisdnLen]=lineRoles;
  
          context.setVariable("obj[msisdn]="+JSON.stringify(obj[msisdnLen]));
      }
      
    
	roles = obj;
		
	for(var rl in roles)
	{
		context.setVariable("roleName=",rl);
		var rlObj = JSON.parse(JSON.stringify(roles[rl]));
		context.setVariable("rlObj=",rlObj);

		var msdn = Object.keys(rlObj)[0];
		context.setVariable("msdn=",msdn);

		var rolesArr = rlObj[msdn];

		context.setVariable("rolesArr=",JSON.stringify(rolesArr));
      	rolesObj[msdn] = rolesArr;

		for(rlIdx=0;rlIdx<rolesArr.length;rlIdx++)
		{
			
			var roleName = rolesArr[rlIdx];
			context.setVariable("roleName=",roleName);

			var roleEntitlements = fnSelectObjectFromBaaS(roleName, OBJ_DATA_TYPE_ROLE_ENTITLEMENT);
			context.setVariable("roleEntitlements=",JSON.stringify(roleEntitlements));
			var roleRoute = fnSelectObjectFromBaaS(roleName, OBJ_DATA_TYPE_ROLE_ROUTE);
			context.setVariable("roleRoute=",JSON.stringify(roleRoute));
			var enabledRoutes = roleRoute[roleName].enabledRoutes;
			context.setVariable("enabledRoutes=",JSON.stringify(enabledRoutes));

			if((enabledRoutes!=null)&&(enabledRoutes!='')&&(enabledRoutes.length>0)&&(roleEntitlements!=null)&&(roleEntitlements!=''))
			{
				for (var i = 0; i < enabledRoutes.length; i++) {
					var routName = enabledRoutes[i];
					context.setVariable("routName=",routName);

					var rPermObj = fnSelectObjectFromBaaS(routName, OBJ_DATA_TYPE_ELEMENT_PERMISSION);
					context.setVariable("rPermObj=",JSON.stringify(rPermObj));

					var uiElementsArr = rPermObj[routName];
					context.setVariable("uiElementsArr",uiElementsArr);

					var ele = {};
                  var usrTmpArr = [];
                  var usrTmp = 0;

					for (uidx = 0; uidx < uiElementsArr.length; uidx++)
				     {
				     	var uiElemntObj = uiElementsArr[uidx];

				     	var uiElemntKey = Object.keys(uiElemntObj)[0];

				     	var uiElementRoleEntlment = uiElemntObj[uiElemntKey].entitlement;				     	

				     	context.setVariable("uiElementRoleEntlment=",uiElementRoleEntlment);
				     	
                        var roleArr = [];//newly added

                        roleArr = roleEntitlements[roleName];//newly added

                         if(roleArr.indexOf(uiElementRoleEntlment)!=-1)//newly added

                       {

				     	//var hasEntitlementValid = fnValidateEntitlements(roleEntitlements, uiElementRoleEntlment);

				     	//if(hasEntitlementValid==true)
				       
							var elementCtrl = uiElemntObj[uiElemntKey].control;
					       context.setVariable("elementCtrl",elementCtrl);

					       if((elementCtrl!=null) && (elementCtrl!=""))
					       {
					        ele[uiElemntKey] = elementCtrl;
					       }
					       else
					       {
					        ele[uiElemntKey] = uiElemntObj[uiElemntKey].defaultControl;
					       }
				     		
				     		usrTmpArr[usrTmp++]=ele;
                     
                        }
				       
				      
				     } 
                  
                  	usr[routName] = usrTmpArr;
                  	usrObj[msdn] = usr;
					//usr[routName] =ele;
				}
            }
		}      
	}

//context.setvariable("usr"+JSON.stringify(usr));
  /*    
      for(var uObj in usrObj) {
	var msisdnKey = Object.keys(uObj)[0];
    usrObj[msisdnKey]=uObj[msisdnKey];
}
*/
/*
uiElements = usrObj;
permissions.roles = rolesObj;
//permissions.roles = roles;
permissions.uiElements = uiElements;
  
var finalResponse = {}; 
finalResponse.user = user;
finalResponse.permissions =permissions;
context.setVariable("finalResponse",JSON.stringify(finalResponse));
context.proxyResponse.content = JSON.stringify(finalResponse); 

}
 catch(err)
    {
     context.proxyResponse.content.asJSON.error = err;
    }
	
}

var usrId = context.getVariable('userId');
processResp = fnProcessPermissions(usrId);
*/