// We can move this to some Key Value service or storage later
var services = {};
services.core = "http://t-mobile-test.apigee.net";
context.setVariable('services',services);

//Headers for core request
var headers = {'Content-Type' : 'application/json', 'senderid' : 'TMO', 'channelid' : 'CARE', 'applicationid' : 'CCO', 'accept' : 'application/json'};

context.setVariable('headers', headers);

//Context for Logging settings
var logSetting = {};

logSetting.baas = {};
logSetting.baas.url = "http://api.usergrid.com/louis.lim5/sandbox/mocks";
context.setVariable('logSetting',logSetting);