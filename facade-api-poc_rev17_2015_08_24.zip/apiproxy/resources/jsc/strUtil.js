/*
Utililty function to strip off all the newline, tab etc characters from the response
  */
function escSpecialChars(jsonString) {

    return jsonString.replace(/\n/g, "")
        .replace(/\r/g, "")
        .replace(/\t/g, "")
        .replace(/\f/g, "");

}