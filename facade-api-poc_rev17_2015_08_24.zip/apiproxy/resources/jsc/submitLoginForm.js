var cookieString = context.getVariable('cookieString'); 
var cookieString2 = context.getVariable('cookieString2');

var baseUrl = 'https://DEVRBLCMSOR21D-ELB-1031444497.us-west-2.elb.amazonaws.com:4445';
var url3 = baseUrl + '/oam/server/auth_cred_submit';

//var url = 'https://www.google.com/';

var headers3 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': cookieString2+";"+cookieString,
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

function serializeQuery(obj) {
  var str = [];
  for (var p in obj) {
    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
  }
  return str.join("&");
}

var bodyObj = {
  "username":"tuser222", 
  "password":"Password_2"
}; 

var myRequest3 = new Request(url3, "POST", headers3, serializeQuery(bodyObj));

var req3 = httpClient.send(myRequest3);

req3.waitForComplete();

var reqResponse3 = req3.getResponse();

// process response3

    var cookieString3 = JSON.stringify(reqResponse3.headers['Set-Cookie']);

    var cookieParts3 = cookieString3.split(';');

    var cookies3 = [];

    for (k in cookieParts3) {
        if (cookieParts3.hasOwnProperty(k)) {
            if (cookieParts3[k].indexOf('httponly') < 0) {
                if (cookieParts3[k].indexOf('path=') < 0) {
                    if (cookieParts3[k].indexOf('domain=') < 0) {
                        if (cookieParts3[k].indexOf('secure') < 0) {
                            if (cookieParts3[k] && cookieParts3[k] != '') {
                                cookies3.push(cookieParts3[k].replace('"', ''));
                            }
                        }
                    }
                }
            }
        }
    }

    // add cookieString to context
    cookieString3 = cookies3.join(';');
    context.setVariable('cookieString3', cookieString3);

var headers4 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': cookieString3 + ";" + cookieString,
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

// submit form 4
var myRequest4 = new Request(url3, "POST", headers4, serializeQuery(bodyObj));

var req4 = httpClient.send(myRequest4);

req4.waitForComplete();

var reqResponse4 = req4.getResponse();

// process req 4, and get authN cookie...
 var cookieString4 = JSON.stringify(reqResponse4.headers['Set-Cookie']);

    var cookieParts4 = cookieString4.split(';');

    var cookies4 = [];

    for (k in cookieParts4) {
        if (cookieParts4.hasOwnProperty(k)) {
            if (cookieParts4[k].indexOf('httponly') < 0) {
                if (cookieParts4[k].indexOf('path=') < 0) {
                    if (cookieParts4[k].indexOf('domain=') < 0) {
                        if (cookieParts4[k].indexOf('secure') < 0) {
                            if (cookieParts4[k] && cookieParts4[k] != '') {
                                cookies4.push(cookieParts4[k].replace('"', ''));
                            }
                        }
                    }
                }
            }
        }
    }

    // add cookieString to context
    cookieString4 = cookies4.join(';');
    context.setVariable('cookieString4', cookieString4);
	context.setVariable('oamCookie', cookieString4);

// now attempt access of protected resource...

var url5 = baseUrl + '/index.html';

var headers5 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': cookieString4,
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

var myRequest5 = new Request(url5, "GET", headers5);

var req5 = httpClient.send(myRequest5);

req5.waitForComplete();

var reqResponse5 = req5.getResponse();


//response.content = JSON.stringify(["submit form >> response >>", reqResponse5, cookieString4]);