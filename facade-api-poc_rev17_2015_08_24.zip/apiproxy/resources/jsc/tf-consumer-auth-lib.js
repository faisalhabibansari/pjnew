// utility functions

function parseCookies(cookieString) {

    var cookieParts = cookieString.split(';');

    var cookies = [];

    for (k in cookieParts) {
        if (cookieParts.hasOwnProperty(k)) {
            if (cookieParts[k].indexOf('httponly') < 0) {
                if (cookieParts[k].indexOf('path=') < 0) {
                    if (cookieParts[k].indexOf('domain=') < 0) {
                        if (cookieParts[k].indexOf('secure') < 0) {
                            if (cookieParts[k] && cookieParts[k] != '') {
                                cookies.push(cookieParts[k].replace('"', ''));
                            }
                        }
                    }
                }
            }
        }
    }
  
    return cookies.join(';');

}


function serializeQuery(obj) {
  var str = [];
  for (var p in obj) {
    str.push(encodeURIComponent(p) + "=" + encodeURIComponent(obj[p]));
  }
  return str.join("&");
}