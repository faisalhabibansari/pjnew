// note: this script depends on tf-consumer-auth-lib.js

// this script calls the initial target (a web-gate protected resource), then gets the redirection url, and loads that form and associated cookies

// get parameters we need from JSON payload
var target_url = context.getVariable('target_url') || '';
var user_name = context.getVariable('user_name') || '';
var password = context.getVariable('password') || '';

// construct protect resource url
var url = target_url + '/index.html';

// construct headers for call
var headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': '',
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

// call protect resource
var myRequest = new Request(url, "GET", headers);

var req = httpClient.send(myRequest);

req.waitForComplete();

var reqResponse = req.getResponse();

// process response
if (reqResponse && reqResponse.headers && reqResponse.status.code === "302") {

    var cookieString = parseCookies(JSON.stringify(reqResponse.headers['Set-Cookie']));
  
    // add cookieString to context
    context.setVariable('cookieString', cookieString);

    // add Location to context
    var locationString = reqResponse.headers.Location;
    context.setVariable('formLocation', locationString);

    // set url for second request
    var url2 = target_url + locationString;

    // set headers
    var headers2 = {
        'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
        'Connection': 'keep-alive',
        'Cookie': cookieString,
        'Accept-Encoding': 'gzip, deflate, sdch',
        'Accept-Language': 'en-US,en;q=0.8',
        'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
    };

    // make actuall form request
    var myRequest2 = new Request(url2, "GET", headers2);

    var req2 = httpClient.send(myRequest2);

    req2.waitForComplete();

    var reqResponse2 = req2.getResponse();

    // process response2
  	if (reqResponse2 && reqResponse2.headers && reqResponse2.status.code === "200") {
    var cookieString2 = parseCookies(JSON.stringify(reqResponse.headers['Set-Cookie']));
    
  	// add cookieString2 to context
    context.setVariable('cookieString2', cookieString2);

	response.content = JSON.stringify([target_url, user_name, password, reqResponse, reqResponse2, cookieString2]);
    
    } else {
      throw new Error("401");
    }
} else {
	throw new Error("401");
}
