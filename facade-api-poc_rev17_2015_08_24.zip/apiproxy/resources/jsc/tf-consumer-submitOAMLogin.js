// note: this script depends on tf-consumer-auth-lib.js

// this script calls the submits the user name and password into the OAM login form

// get parameters we need from JSON payload
var target_url = context.getVariable('target_url') || '';
var user_name = context.getVariable('user_name') || '';
var password = context.getVariable('password') || '';

// get cookieStrings from previous step
var cookieString = context.getVariable('cookieString'); 
var cookieString2 = context.getVariable('cookieString2');

// set url for form submission
var url3 = target_url + '/oam/server/auth_cred_submit';

// set headers
var headers3 = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': cookieString2+";"+cookieString,
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

// set data payload
var bodyObj = {
  "username":user_name, 
  "password":password
}; 


var myRequest3 = new Request(url3, "POST", headers3, serializeQuery(bodyObj));

var req3 = httpClient.send(myRequest3);

req3.waitForComplete();

var reqResponse3 = req3.getResponse();

// process response3

    var cookieString3 = parseCookies(JSON.stringify(reqResponse3.headers['Set-Cookie']));

    // add cookieString to context
    context.setVariable('cookieString3', cookieString3);

//var headers4 = {
//    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
//    'Connection': 'keep-alive',
//    'Cookie': cookieString3 + ";" + cookieString,
//    'Accept-Encoding': 'gzip, deflate, sdch',
//    'Accept-Language': 'en-US,en;q=0.8',
//   'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
//};

// submit form 4
//var myRequest4 = new Request(url3, "POST", headers4, serializeQuery(bodyObj));

//var req4 = httpClient.send(myRequest4);

//req4.waitForComplete();

//var reqResponse4 = req4.getResponse();

// process req 4, and get authN cookie...
// var cookieString4 = parseCookies(JSON.stringify(reqResponse4.headers['Set-Cookie']));

    // add cookieString to context
//    context.setVariable('cookieString4', cookieString4);
//	context.setVariable('oamCookie', cookieString4);

response.content = JSON.stringify(["submit form >> reqResponse3 >>", reqResponse3]);