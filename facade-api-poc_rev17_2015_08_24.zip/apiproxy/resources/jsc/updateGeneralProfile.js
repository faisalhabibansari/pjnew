var customerId = context.getVariable('customerId');
//var url = 'http://t-mobile-test.apigee.net/tmo/v1/customers/'+customerId+'/general-profile';
var url = 'http://t-mobile-prod.apigee.net/customer/'+customerId;

var reqPayLoad = context.targetRequest.body.asJSON
var headers = {'Content-Type' : 'application/json'};
var myRequest = new Request(url,"POST",headers,JSON.stringify(reqPayLoad));
var req = httpClient.send(myRequest);

req.waitForComplete();
var response = req.getResponse().content.asJSON;


context.proxyResponse.content = JSON.stringify(response); 

