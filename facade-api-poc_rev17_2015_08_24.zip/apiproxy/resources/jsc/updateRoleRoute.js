var reqContent = context.getVariable('request.content');
context.setVariable('reqContent', reqContent);
/*
utility function to concatenate arrays and remove duplicate values
array contains string values for the purpose of this implementation
*/
function concatArrUnique(array) {
    var a = array.concat();
    for(var i=0; i<a.length; ++i) {
        for(var j=i+1; j<a.length; ++j) {
            if(a[i] === a[j])
                a.splice(j--, 1);
        }
    }

    return a;
}

/*
utility function to validate request payload elements
*/
function fnValidateInputRouteList(aObj, roleName) 
{

	var res1=concatArrUnique(aObj[roleName].enabledRoutes.concat(aObj[roleName].protectedRoutes));
	var res=concatArrUnique(res1.concat(aObj[roleName].disabledRoutes));

	var enabledRoutesLen = aObj[roleName].enabledRoutes.length;
	var disabledRoutesLen = aObj[roleName].protectedRoutes.length;
	var protectedRoutesLen = aObj[roleName].disabledRoutes.length;

	var routesLen=(enabledRoutesLen+disabledRoutesLen+protectedRoutesLen);

	if(routesLen==0)
	{
		return false;
	}

	if(res.length<(routesLen))
	{
		
		return false;
	}
	else if(res.length==(routesLen))
	{
		
		return true;
	}
}

/*
function to update Baas role-route object
inputs::
  routeObjUUID: String (object Id)
  roleName: String
  roleRoutePayload: JSON Object (for routes to be updated)
*/
function fnPostRoleRoute(routeObjUUID, roleName, roleRoutePayload) {
  
  context.setVariable('ur_fnPostRoleRoute_routeObjUUID', routeObjUUID);
  
  var objUUID = routeObjUUID;
  
  context.setVariable('ur_fnPostRoleRoute_objUUID', objUUID);
  
  var url = "https://api.usergrid.com/louis.lim5/sandbox/mocks/" + objUUID;
  
  context.setVariable('ur_fnPostRoleRoute_url', url);
  
  
  var headers = {'Content-Type' : 'application/json'};
  
  //Create Role Route Object to be updated
  var mObj = {};
  
  mObj.dataType='roleRoute';
  mObj.id=roleName;
  mObj.mockData=roleRoutePayload;
  
  //Create request object with payload and headers
  var reqPayload = JSON.stringify(mObj);  
 context.setVariable('reqPayload', reqPayload);
  
  
  var myRequest = new Request(url,"PUT",headers, reqPayload);
  var req = httpClient.send(myRequest);

  req.waitForComplete();
  
  if (req.isSuccess()) {
    //
    context.setVariable('req.isSuccess()', req.isSuccess());
  }
  
};


/*
utility function to extract request payload elements
*/
function extractRouteReqPayload(reqPayloadContent)
{
	//valid

	//var reqPayloadContent = {"account-viewer":{"enabledRoutes":["/accounts","/home"],"protectedRoutes":["/accounts/payments"],"disabledRoutes":["/accounts/lines"]}};
	
	context.setVariable('reqPayloadContent', reqPayloadContent);

	
    if((reqPayloadContent!=null)&&(reqPayloadContent!=''))
    {
    	
      	//var prxyRequestPayload = JSON.parse(JSON.stringify(reqPayloadContent));
      
      	
      	var prxyRequestPayload = JSON.parse(reqPayloadContent);
		context.setVariable('prxyRequestPayload', prxyRequestPayload);
      	return prxyRequestPayload;
     }      
}

/*
utility function to extract role name element
*/
function extractRoleName(prxyRequestPayload)
{
	 var roleName = Object.keys(prxyRequestPayload)[0].toString();
	       
     context.setVariable('ur1_roleName', roleName);

      return roleName;
}

/*
utility function to validate request payload elements
*/
function validateRouteReqPayload(prxyRequestPayload, roleName)
{
      
      var enabledRoutes = prxyRequestPayload[roleName].enabledRoutes;
      
      context.setVariable('ur2_enabledRoutes', JSON.stringify(enabledRoutes));
      
      var protectedRoutes = prxyRequestPayload[roleName].protectedRoutes;
      
      context.setVariable('ur3_protectedRoutes', JSON.stringify(protectedRoutes));
      
      var disabledRoutes = prxyRequestPayload[roleName].disabledRoutes;
      
      context.setVariable('ur4_disabledRoutes', JSON.stringify(disabledRoutes));

      var boolIsRouteListValid = fnValidateInputRouteList(prxyRequestPayload, roleName);

      return boolIsRouteListValid;
	
}

/*
utility function to create request payload for updating data
*/
function createUpdateReqPayload(roleName, prxyRequestPayload, routeListJSON)
{
	var reqPayload = {};

	
	var enabledRoutes = prxyRequestPayload[roleName].enabledRoutes;
    
    context.setVariable("enabledRoutes"+JSON.stringify(enabledRoutes));
	
	var protectedRoutes = prxyRequestPayload[roleName].protectedRoutes;
	context.setVariable("protectedRoutes"+JSON.stringify(protectedRoutes));

	var disabledRoutes = prxyRequestPayload[roleName].disabledRoutes;
	context.setVariable("disabledRoutes"+JSON.stringify(disabledRoutes));

	
	if((enabledRoutes!=null)&&(enabledRoutes!='')&&(enabledRoutes.length>0)){

		if((routeListJSON[roleName].enabledRoutes!=null)&&(routeListJSON[roleName].enabledRoutes!='')&&(routeListJSON[roleName].enabledRoutes.length>0)) {

		  var uniqEnabledRoutes = concatArrUnique(enabledRoutes.concat(routeListJSON[roleName].enabledRoutes));
		  
		  reqPayload.enabledRoutes = uniqEnabledRoutes;

			context.setVariable("reqPayload.enabledRoutes"+JSON.stringify(reqPayload.enabledRoutes));
		  
		}
		else
		{
		  //directly add the elements as none are present
		  reqPayload.enabledRoutes = enabledRoutes;
		  context.setVariable("reqPayload.enabledRoutes"+JSON.stringify(reqPayload.enabledRoutes));
		  
		}
	}

	//protected routes
    if((protectedRoutes!=null)&&(protectedRoutes!='')&&(protectedRoutes.length>0)){

      if((routeListJSON[roleName].protectedRoutes!=null)&&(routeListJSON[roleName].protectedRoutes!='')&&(routeListJSON[roleName].protectedRoutes.length>0)) {
    
        var uniqProtectedRoutes = concatArrUnique(protectedRoutes.concat(routeListJSON[roleName].protectedRoutes));
  
        reqPayload.protectedRoutes = uniqProtectedRoutes;

        context.setVariable("reqPayload.protectedRoutes"+JSON.stringify(reqPayload.protectedRoutes));
        

      }
      else
      {
        //directly add the elements as none are present
        reqPayload.protectedRoutes = protectedRoutes;
        context.setVariable("reqPayload.protectedRoutes"+JSON.stringify(reqPayload.protectedRoutes));
        
        
        }
      }

      //disabledRoutes routes
      if((disabledRoutes!=null)&&(disabledRoutes!='')&&(disabledRoutes.length>0)){

        if((routeListJSON[roleName].disabledRoutes!=null)&&(routeListJSON[roleName].disabledRoutes!='')&&(routeListJSON[roleName].disabledRoutes.length>0)) {
    
          var uniqDisabledRoutes = concatArrUnique(disabledRoutes.concat(routeListJSON[roleName].disabledRoutes));
  
          reqPayload.disabledRoutes = uniqDisabledRoutes;

		  context.setVariable("reqPayload.disabledRoutes"+JSON.stringify(reqPayload.disabledRoutes));
          
          
        }
        else
        {
          //directly add the elements as none are present
          reqPayload.disabledRoutes = disabledRoutes;

          context.setVariable("reqPayload.disabledRoutes"+JSON.stringify(reqPayload.disabledRoutes));


          
        }

      }

	var updatePayload = {};
	updatePayload[roleName] = reqPayload;
    
    return updatePayload;
	
	

}

/*
main function to process request payload and post updated data
*/
function processUpdateRouteReqPayload(requestPayloadContent)
{
	try 
	{
		var reqPayloadContent = extractRouteReqPayload(requestPayloadContent);

		var roleName = extractRoleName(reqPayloadContent);

		var bIsRouteListValid = validateRouteReqPayload(reqPayloadContent, roleName);

		if(bIsRouteListValid==true)
		{
			
			//context.setVariable('processUpdateRouteReqPayload():roleName:', roleName);

			var respObj = fnGetRoutes(roleName);
			
			if(respObj!=null)
			{

				var routeListEnt = respObj.entities;
				
				var routeList = JSON.stringify(routeListEnt[0].mockData);
	   				   			
	   			var routeListJSON = JSON.parse(routeList);

				context.setVariable("routeListJSON"+JSON.stringify(routeListJSON));
								
				var roleNameFrmRouteListJSON = extractRoleName(routeListJSON);
				context.setVariable("roleNameFrmRouteListJSON"+roleNameFrmRouteListJSON);
				
				if(roleName==roleNameFrmRouteListJSON)
				{

					var reqPayload = createUpdateReqPayload(roleName, reqPayloadContent, routeListJSON);

					var routeObjUUID = routeListEnt[0].uuid;
        			context.setVariable('ur99_reqPayload', routeObjUUID);
        			fnPostRoleRoute(routeObjUUID, roleName, reqPayload);
				}
			}
			
		}
		
		
	}
	catch(err)
	{
		context.proxyResponse.content.asJSON.error = err;
	}

}


processUpdateRouteReqPayload(reqContent);