// this is for CARE and RETAIL, once we got the cookie call oam to verify the cookie
// detail for this call pending specs e.g. url , request payload 
// base on that result set 'oauth_external_authorization_status' below
// if there is more data needed to be set for login in user, set here and add it to 'getAccessTokenOAuth' policy

var cookieString = context.proxyRequest.headers['Cookie'];
//context.setVariable("headersToast", headers);
//response.content = headers;
var oamCookie = context.proxyRequest.queryParams['externalAccessToken'];
var serverInfo = context.getVariable('request.queryparam.server');

//var oamCookie = context.proxyRequest.queryParams['externalAccessToken'];

//var url = "http://devrblcmsor21d-elb-1031444497.us-west-2.elb.amazonaws.com:4443";   // serverInfo
var url = 'http://www.google.com';


var myRequest = new Request(url,"GET", cookieString);
var req = httpClient.send(myRequest);
req.waitForComplete();
var response = req.getResponse();

if (req.isSuccess()) {
  var status = response.status;
 
  
  if (status == 200){
    //Grab cookie from header
    var cookie2 = cookieString.split( ';' ).map( function( x ) { return x.trim().split( /(=)/ ); } ).reduce( function( a, b ) { a[ b[ 0 ] ] = a[ b[ 0 ] ] ? a[ b[ 0 ] ] + ', ' + b.slice( 2 ).join( '' ) :  b.slice( 2 ).join( '' ); return a; }, {} );
    var cookie_test = cookie2['OAMAuthnCookie_' + serverInfo];
    //context.setVariable('cookie_test', cookie_test);
    context.proxyResponse.content = cookie_test;
    
    // Need to cache the cookie
    //ttl == 1/4 of 30 minutes
    /* context.setVariable('oam_cookie',oamCookie); //Caching will take place of this
     context.setVariable('loggedinUserId',context.proxyRequest.queryParams['loggedinUserId']);*/
    
  } 
  else {
   context.proxyResponse.content = 'Status was not 200'; 
  }
}
else {
	context.proxyResponse.content = "error"; 
}
/*else {
  var retCode = "401"; 
   return retCode;
}*/
