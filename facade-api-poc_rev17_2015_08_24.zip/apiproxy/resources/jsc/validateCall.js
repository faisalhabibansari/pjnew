  var incomingToken = context.proxyRequest.headers['Authorization'];

  //var bearer = "Bearer " + incomingToken;
  context.setVariable("incomingToken", incomingToken);
  
  var headers = {"Authorization": incomingToken};

context.setVariable("headersToast", JSON.stringify(headers));
  
//var url = 'http://www.google.com';
  var url = 'https://66.94.14.141/userprofile/p/v1/userinfo';  

  var myRequest = new Request(url,"HEAD",headers);
  var req = httpClient.send(myRequest);
  
  req.waitForComplete();
  var response = req.getResponse();

context.setVariable("responseToast", response);
context.setVariable("responseStatus", response.status);

/*if (response.status == 200) {
  
}

else {
  
}*/