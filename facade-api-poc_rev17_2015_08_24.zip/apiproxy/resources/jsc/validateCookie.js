

var oamCookie = context.getVariable('oamCookie');

// given a cookie, let's validate that it's good

var baseUrl = 'https://DEVRBLCMSOR21D-ELB-1031444497.us-west-2.elb.amazonaws.com:4445';
var url = baseUrl + '/index.html';

//var url = 'https://www.google.com/';

var headers = {
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Connection': 'keep-alive',
    'Cookie': oamCookie,
    'Accept-Encoding': 'gzip, deflate, sdch',
    'Accept-Language': 'en-US,en;q=0.8',
    'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.89 Safari/537.36'
};

var myRequest = new Request(url, "GET", headers);

var req = httpClient.send(myRequest);

req.waitForComplete();

var reqResponse = req.getResponse();


response.content = JSON.stringify(["validating cookie, protected resource >>", reqResponse]);