var result = {'success':true};

context.proxyResponse.content = JSON.stringify(result);