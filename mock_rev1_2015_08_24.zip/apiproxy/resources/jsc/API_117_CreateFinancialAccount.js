var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null)
{
    context.setVariable('dataType', 'CreateFinancialAccount');
  context.setVariable("objectId", "234234");
}
    