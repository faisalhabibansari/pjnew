/*var id = context.getVariable("id")
var reqPayLoad = context.targetRequest.body.asJSON;
context.setVariable("dataType","DeviceTradeInEstimate");

if(id!=null && id!='') {
	var msisdn = reqPayLoad.msisdn;
	var imei = reqPayLoad.imei;
	var diagnosticCode = reqPayLoad.diagnosticCode;
  
	if (msisdn == "2061234567" && imei == "479003655217498" && diagnosticCode=="1234567"){
       context.setVariable("objectId","1234");
	}else if (msisdn == "3512987777" && imei == "229936044654371" && diagnosticCode=="1234567"){
       context.setVariable("objectId","6541");
	}else if (id=="12345" && msisdn == "2061234567" && imei == "479003655217498"){
       context.setVariable("objectId","6542");
	}else if (msisdn == "3512987777" && imei == "229936044654371"){
       context.setVariable("objectId","2148");
	}else if (msisdn == "6354781111" && imei == "535934655968759"){
       context.setVariable("objectId","3844");
	}else if (id=="12345" && msisdn == "6021234577" && imei == "001687513259884"){
       //context.setVariable("objectId","5874");
       context.setVariable("objectId","6543");
    }else if (id=="23456" && msisdn == "2061234567" && imei == "479003655217498"){
    	context.setVariable("objectId","6544");
    }else if (id=="23456" && msisdn == "6021234577" && imei == "001687513259884"){
    	context.setVariable("objectId","6545");
    }else if (id=="34567" && msisdn == "2061234567" && imei == "479003655217498"){
    	context.setVariable("objectId","6544");
    }else if (id=="34567" && msisdn == "6021234577" && imei == "001687513259884"){
    	context.setVariable("objectId","6545");
    }else{
	   context.setVariable("objectId","0000");
	}
}else{
	   context.setVariable("objectId","0000");
}*/

var id = context.getVariable("id")
var reqPayLoad = context.targetRequest.body.asJSON;
context.setVariable("dataType","DeviceTradeInEstimate");

if(id!=null && id!='') {
	var msisdn = reqPayLoad.msisdn;
	var imei = reqPayLoad.imei;
	var diagnosticCode = reqPayLoad.diagnosticCode;
  
	if (msisdn == "2061234567" && imei == "479003655217498" && diagnosticCode=="1234567"){
       context.setVariable("objectId","1234");
	}else if (msisdn == "3512987777" && imei == "229936044654371" && diagnosticCode=="1234567"){
       context.setVariable("objectId","6541");
	}else if (id=="12345" && msisdn == "2061234567" && (imei == "479003655217498" || imei == "479003655218498" || imei == "479003655219498")){
       context.setVariable("objectId","8110");
	}else if (msisdn == "3512987777" && imei == "229936044654371"){
       context.setVariable("objectId","2148");
	}else if (id=="12345" && msisdn == "6354781111" && (imei == "535934655968759" || imei =="535934655978759" || imei == "535934655988759")){
       context.setVariable("objectId","8112");
	}else if (id=="12345" && msisdn == "6021234577" && (imei == "001687513259884" || imei =="001687513259884" || imei == "001687513258884" || imei =="001687513257884")){
       context.setVariable("objectId","8111");
    }else if (id=="23456" && msisdn == "2061234567" && imei == "479003655217498" ){
    	context.setVariable("objectId","6544");
    }else if (id=="23456" && msisdn == "6021234577" && imei == "001687513259884"){
    	context.setVariable("objectId","6545");
    }else if (id=="34567" && msisdn == "2061234567" && imei == "479003655217498"){
    	context.setVariable("objectId","6544");
    }else if (id=="34567" && msisdn == "6021234577" && imei == "001687513259884"){
    	context.setVariable("objectId","6545");
    }else if (id=="33456" && msisdn == "3061234567" && imei == "479333655217498"){
    	context.setVariable("objectId","8123");
    }else if (id=="33456" && msisdn == "7021234577" && imei == "001687513259884"){
    	context.setVariable("objectId","8124");
    }else if (id=="33456" && msisdn == "8121234577" && imei == "001687593259884"){
    	context.setVariable("objectId","8125");
    }else if (id=="33456" && msisdn == "7021234588" && imei == "001687513254444"){
    	context.setVariable("objectId","8126");
    }
  else if (id=="56789" && msisdn == "2015200411" && imei == "201520041111111"){
context.setVariable("objectId","8127");
}else if (id=="56789" && msisdn == "2015200422" && imei == "201520042211111"){
context.setVariable("objectId","8128");
}else if (id=="20041" && msisdn == "2015200433" && (imei == "201520043311111" || imei == "201520043311112" || imei == "201520043311113")){
context.setVariable("objectId","8129");
}else if (id=="20041" && msisdn == "2015200444" && (imei == "201520044411111" || imei == "201520044411112" || imei == "201520044411113")){
context.setVariable("objectId","8130");
}else if (id=="20041" && msisdn == "2015200455" && (imei == "201520045511111" || imei == "201520045511112" )){
context.setVariable("objectId","8131");
}else if (id=="20042" && msisdn == "2015200466" && imei == "201520046611111"){
context.setVariable("objectId","8132");
}
else if (id=="20043" && msisdn == "2015777777" && imei == "201520046777777"){
context.setVariable("objectId","8133");
}
  else if (id=="20043" && msisdn == "2015888888" && imei == "201520046888888"){
context.setVariable("objectId","8134");
}
  else if (id=="20044" && msisdn == "2015042711" && imei == "001612015042711"){
context.setVariable("objectId","8135");
}
   else if (id=="20044" && msisdn == "2015042722" && imei == "001682015042722"){
context.setVariable("objectId","8136");
}
  else if (id=="56789" && msisdn == "2015280411" && imei == "201528041111111"){
context.setVariable("objectId","8137");
}
  else if (id=="56789" && msisdn == "2015280411" && imei == "201528041111112"){
context.setVariable("objectId","8138");
}
  else if (id=="20045" && msisdn == "2015042911" && imei == "201504291111111"){
context.setVariable("objectId","8139");
}
  else if (id=="20045" && msisdn == "2015042911" && imei == "201504291111112"){
context.setVariable("objectId","8140");
}
  else if (id=="20045" && msisdn == "2015042911" && imei == "201504291111113"){
context.setVariable("objectId","8140");
}

  else{
	   context.setVariable("objectId","0000");
	}
}else{
	   context.setVariable("objectId","0000");
}

