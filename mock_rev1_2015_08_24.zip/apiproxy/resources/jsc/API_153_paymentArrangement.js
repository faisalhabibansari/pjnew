var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");

var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var type = request_payload.paymentMethod.type;

if(customerId=='123321' && accountId=='123321' && (type=='credit card'||type=='checking account'||type=='none')){      
	context.setVariable("objectId", "000000");
}else if(customerId=='12345' && accountId=='55555'){
	context.setVariable("objectId", "000001");
}else if(customerId=='12345' && accountId=='55556'){
	context.setVariable("objectId", "000002");
}else if(customerId=='55555' && accountId=='12345667'){
	context.setVariable("objectId", "000003");
}else if(customerId=='234234235' && accountId=='123456789'){
 	context.setVariable("objectId", "000004");
}else{
  context.setVariable("objectId", "");
}

context.setVariable('dataType', 'paymentArrangement');