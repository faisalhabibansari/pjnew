var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
var paymentArrangementId = context.getVariable("paymentArrangementId");

var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!=''){
	request_payload = JSON.parse(context.getVariable('request.content'));
}

if(customerId=='123321' && accountId=='123321' && paymentArrangementId=='123321'){
    if(JSON.stringify(request_payload).indexOf('cancellation')>=0){
    	context.setVariable("objectId","checkingxxxx0202");  // Cancellation
    }else if(JSON.stringify(request_payload).indexOf('paymentMethod')>=0){
    	context.setVariable("objectId","000013"); // Update
    }else{
     	context.setVariable("objectId","");
    }
}else if(customerId=='12345' && accountId=='55555' && paymentArrangementId=='123321'){
    if(JSON.stringify(request_payload).indexOf('cancellation')>=0){
    	context.setVariable("objectId","000005");  // Cancellation
    }else if(JSON.stringify(request_payload).indexOf('paymentMethod')>=0){
    	context.setVariable("objectId","000009"); // Update
    }else{
     	context.setVariable("objectId","");
    }
}else if(customerId=='12345' && accountId=='55556' && paymentArrangementId=='123321'){
    if(JSON.stringify(request_payload).indexOf('cancellation')>=0){
    	context.setVariable("objectId","000006");  // Cancellation
    }else if(JSON.stringify(request_payload).indexOf('paymentMethod')>=0){
    	context.setVariable("objectId","000010"); // Update
    }else{
     	context.setVariable("objectId","");
    }
}else if(customerId=='55555' && accountId=='12345667' && paymentArrangementId=='123321'){
    if(JSON.stringify(request_payload).indexOf('cancellation')>=0){
    	context.setVariable("objectId","000007");  // Cancellation
    }else if(JSON.stringify(request_payload).indexOf('paymentMethod')>=0){
    	context.setVariable("objectId","000011"); // Update
    }else{
     	context.setVariable("objectId","");
    }
}else if(customerId=='234234235' && accountId=='123456789' && paymentArrangementId=='123321'){
    if(JSON.stringify(request_payload).indexOf('cancellation')>=0){
    	context.setVariable("objectId","000008");  // Cancellation
    }else if(JSON.stringify(request_payload).indexOf('paymentMethod')>=0){
    	context.setVariable("objectId","000012"); // Update
    }else{
     	context.setVariable("objectId","");
    }
}
context.setVariable('dataType', 'paymentArrangement');