//Author: Chandan Chawla
// this script fetch the template variable servicePlanId from the url and assigns it to objectId which is then used to fetch proper response from the usergrid.

var servicePlanId=context.getVariable("servicePlanId");

if(servicePlanId!=null)
{
  context.setVariable("objectId", servicePlanId);
}