var customerId = context.getVariable("customerId");
var accountId = context.getVariable("objectId");

context.setVariable("dataType",'easyPaySetup');

var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var paymentMethod = request_payload.paymentMethod;
if(paymentMethod!=null)
{
 var type = paymentMethod.type;
 var refNumber = paymentMethod.refNumber;
  if(customerId=="12345" && accountId=="55555")
  {
    if(type=="credit card")
    {
        if(refNumber!=null)
         {
           context.setVariable("objectId",'000001');
         }
        else
         {
           context.setVariable("objectId",'000002');
         }
    }
    else if(type=="checking account")
    {
     context.setVariable("objectId",'000003');
    }
  }
  
  else if(customerId=="12345" && accountId=="55556")
  {
    if(type=="credit card")
    {
        if(refNumber!=null)
         {
           context.setVariable("objectId",'000004');
         }
        else
         {
           context.setVariable("objectId",'000005');
         }
    }
    else if(type=="checking account")
    {
     context.setVariable("objectId",'000006');
    }
  }
 
  else if(customerId=="55555" && accountId=="12345667")
  {
    if(type=="credit card")
    {
        if(refNumber!=null)
         {
           context.setVariable("objectId",'000007');
         }
        else
         {
           context.setVariable("objectId",'000008');
         }
    }
    else if(type=="checking account")
    {
     context.setVariable("objectId",'000009');
    }
  }
  
  else if(customerId=="123321" && accountId=="123321")
  {
    if(type=="credit card")
    {
        if(refNumber!=null)
         {
           context.setVariable("objectId",'000010');
         }
        else
         {
           context.setVariable("objectId",'000011');
         }
    }
    else if(type=="checking account")
    {
     context.setVariable("objectId",'000012');
    }
  }
  
  else if(customerId=="234234235" && accountId=="123456789")
  {
    if(type=="credit card")
    {
        if(refNumber!=null)
         {
           context.setVariable("objectId",'000013');
         }
        else
         {
           context.setVariable("objectId",'000014');
         }
    }
    else if(type=="checking account")
    {
     context.setVariable("objectId",'000015');
    }
  }
  
}


//if((customerId=='55555' && accountId=='12345667') || (customerId=='12345' && accountId=='55555') )
//if(customerId!=null && accountId!=null && customerId!='' && accountId!='')
//{
 // context.setVariable("objectId",'000000');
//}
 