
var id = context.getVariable("objectId");
var reqPayLoad = context.targetRequest.body.asJSON;

if(id!=null && id == '1234'){
	context.setVariable("objectId",'1234');
} else if(id!=null && id == '1222'){
   context.setVariable("objectId",'1222');
}
else if(id!=null && id == '1300'){
  if (reqPayLoad.hasOwnProperty('payment')){
   if(reqPayLoad.payment.cardNumber=="4915491549154915"){
     	context.setVariable("objectId","1306");
     }else if (reqPayLoad.payment.paymentMethod=="CheckingAccount" && reqPayLoad.payment.accountNumber=="212012045150156") {
        context.setVariable("objectId","1307");
     }else if (reqPayLoad.payment.paymentMethod=="CreditCard" && reqPayLoad.payment.nameOnCard=="JohnJDoe") {
        context.setVariable("objectId","1308");
     }  
  }else if (reqPayLoad.hasOwnProperty('items')){
    if(!reqPayLoad instanceof Array && reqPayLoad.items[0].productId == 'pln2512' && reqPayLoad.items[1].productId == 'pln2516') {
		context.setVariable("objectId","1301");
	 }else if(!reqPayLoad instanceof Array && reqPayLoad.items[0].productId == 'pln2513' && reqPayLoad.items[1].productId == 'pln2517') {
		context.setVariable("objectId","1302");
}
  }
}
else if(reqPayLoad.items[0].productId !=null && reqPayLoad.items[0].productId == '11') {
	context.setVariable("objectId",reqPayLoad.items[0].productId);
}
else if(id!=null && id == '1200') {
	if (!(reqPayLoad instanceof Array) && reqPayLoad.promotions[0].id == 'TMOBILESAVE25'){
		context.setVariable("objectId",reqPayLoad.promotions[0].id);
	}else if (reqPayLoad instanceof Array && reqPayLoad[0].productId == '10001') {
		context.setVariable("objectId","10003");
	}else{
	   context.setVariable("objectId","0000");
	}
}else if (reqPayLoad instanceof Array && reqPayLoad[0].productId == '10001') {
	context.setVariable("objectId",reqPayLoad[0].productId);
}else if(!reqPayLoad instanceof Array && reqPayLoad.items[0].productId == 'pln2512' && reqPayLoad.items[1].productId == 'pln2516') {
		context.setVariable("objectId","1301");
	 }else if(!reqPayLoad instanceof Array && reqPayLoad.items[0].productId == 'pln2513' && reqPayLoad.items[1].productId == 'pln2517') {
		context.setVariable("objectId","1302");
}else{
	context.setVariable("objectId",id);
}

context.setVariable("dataType","addToCart");

