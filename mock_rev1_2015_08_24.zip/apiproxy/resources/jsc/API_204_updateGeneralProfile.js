var objectId = context.getVariable("objectId");

var request_payload = '';
if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='')
{
request_payload = JSON.parse(context.getVariable('request.content'));
}

var id = request_payload.id;
var phoneNumber = request_payload.phoneNumber;
var accounts = request_payload.accounts;
var language = request_payload.language;
var timeZone = request_payload.timeZone;
var firstName = request_payload.firstName;
var lastName = request_payload.lastName;

var userName = request_payload.userName;// Sprint 41
var emailAddress = request_payload.emailAddress;// Sprint 41
var securityQuestions = request_payload.securityQuestions;// Sprint 41
var nickName = request_payload.nickName;// Sprint 41
var passsword = request_payload.passsword;// Sprint 41
var pin = request_payload.pin;// Sprint 41

var addresses = request_payload.addresses;// Sprint 43

context.setVariable("dataType","updateGeneralProfile");

 if(id=='234234234')
 {
     if(phoneNumber=='7325568899')
      {
          context.setVariable("objectId", "001"); 
      }
    
     else if(firstName=='John'&& lastName=='Doe')
      {
          context.setVariable("objectId", "002"); 
      }
     else if(timeZone!=null&&timeZone.code=='2')
      {
          context.setVariable("objectId", "003"); 
      }
      else if((language!=''&& accounts!='')&&(language!=null && accounts!=null))
      {
         context.setVariable("objectId", "004"); 
      }
       else if(accounts!=''&& accounts!=null)
      {
        if(accounts[0].lines[0].nickName=='New Name')
        {
        context.setVariable("objectId", "005");
        }
        else
        {
         context.setVariable("objectId", "006");
        }
      }
      else if(language!=''&& language!=null && language.code=="2")
      {
         context.setVariable("objectId", "007"); 
      }
      else if(userName =='JohnSmith')
      {
         context.setVariable("objectId", "008"); 
      }
      else if(emailAddress =='JohnSmith@gmail.com')
      {
         context.setVariable("objectId", "009"); 
      }
      else if(securityQuestions !=''&&securityQuestions !=null)
      {
         context.setVariable("objectId", "010"); 
      }
      else if(nickName =='My NickName PC - new')
      {
         context.setVariable("objectId", "011"); 
      }
      else if(passsword =='Test12345'&&pin =='3456')
      {
         context.setVariable("objectId", "012"); 
      }
   	  else if(addresses[0].addressLine1 != '' && addresses[0].addressLine1 != '123ppuSt')
      {
         context.setVariable("objectId", "013"); 
      }
 }