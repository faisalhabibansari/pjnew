
context.setVariable("dataType","CreditCheck");