//var request_payload = '';

//if(context.getVariable('request.content')!=null&&context.getVariable('request.content')!='') {
	//request_payload = JSON.parse(context.getVariable('request.content'));
//}

//if (request_payload.lines[0].id == '2061234567') 
//{

	//context.setVariable("objectId", "2061234567");
  	//context.setVariable("dataType","banToBanConflicts");
//}
//var type=context.getVariable("request.queryparam.type");

var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
var type=context.getVariable("request.queryparam.type");
context.setVariable("dataType","banToBanConflicts");

if(customerId == "234234200" && type=='plans' && accountId =="123127"){
  context.setVariable("objectId", "003");  
}else if(customerId == "234234200" && type=='plans' && accountId =="123456"){
  context.setVariable("objectId", "004");  
}else if(customerId == "234234200" && type=='services' && accountId =="123127"){
  context.setVariable("objectId", "005");  
}else if(customerId == "234234200" && type=='services' && accountId =="123456"){
  context.setVariable("objectId", "006");  
}else if(customerId == "234234328" && type=='plans' && accountId =="123123"){
  context.setVariable("objectId", "015");  
}else if(customerId == "234234328" && type=='plans' && accountId =="123127"){
  context.setVariable("objectId", "008");  
}else if(customerId == "234234328" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "010");  
}else if(customerId == "234227000" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "011");  
}else if(customerId == "234227001" && type=='services' && accountId =="123123"){
  context.setVariable("objectId", "012"); 
}else if(customerId == "234234200" && type=='plans' && accountId =="123126"){
  context.setVariable("objectId", "013");  
}else if(customerId == "234234328" && type=='plans' && accountId =="123124"){
  context.setVariable("objectId", "014");  
}else if(type =='plans'){
  context.setVariable("objectId", "001");  
}else if(type =='services'){
  context.setVariable("objectId", "002");  
}
context.setVariable("dataType","banToBanConflicts");