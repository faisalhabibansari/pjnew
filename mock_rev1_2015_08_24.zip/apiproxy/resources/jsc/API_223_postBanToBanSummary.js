var reqPayLoad = context.targetRequest.body.asJSON
var accountId = context.getVariable("accountId")
var customerId = context.getVariable("customerId")
if(reqPayLoad!=null){ 
  if(customerId=='234234200' && accountId=='123127'){
    context.setVariable("objectId", "123127");
  }else if(customerId=='234234200' &&  accountId=='123456'){
    context.setVariable("objectId", "123456");
  }else if(customerId=='234234200' &&  accountId=='123126'){
    context.setVariable("objectId", "123126");
  }else if(customerId=='234234328' &&  accountId=='123123'){
    context.setVariable("objectId", "123123");
  }else{
    context.setVariable("objectId", "12345");
  }
}
else
{
    context.setVariable("objectId","0000");
}
context.setVariable("dataType", "postBanToBanSummary");