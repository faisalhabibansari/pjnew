var storeId= context.proxyRequest.queryParams['id'];
var macAddress= context.proxyRequest.queryParams['macAddress'];

if((storeId != '' &&  storeId =='1000') || (macAddress != '' &&  macAddress=='00-15-E9-2B-99-3C')){
	context.setVariable("objectId", "1000");
	context.setVariable("dataType", "getRetailStores");

}else if((storeId != '' &&  storeId =="2000") || (macAddress != '' &&  macAddress=='00-16-41-34-2C-A6')){
	context.setVariable("objectId", "2000");
	context.setVariable("dataType", "getRetailStores");
}