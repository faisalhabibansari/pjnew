var storeId=context.getVariable("storeId");

var terminalId=context.getVariable("terminalId");


var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null && storeId != null && terminalId != null)
{
  if((storeId != "") && (storeId=="1000") && (terminalId != "") && (terminalId=="t100"))
  {
   var tillId=reqPayLoad.tillId;
   var status=reqPayLoad.status;
   var balance = reqPayLoad.balance
   
   context.setVariable("dataType","RetailStoresTill");
    
   if(tillId==null&&status=="open"&&balance!=null)
   {
	 context.setVariable("objectId", "1");	            
   }  
   else if(tillId=="t100"&&status=="closed"&&balance!=null)
   {
	 context.setVariable("objectId", "2");	            
   }
   else if(tillId=="1L1FA"&&status=="closed"&&balance!=null)
   {
	 context.setVariable("objectId", "3");	            
   }
   else if(tillId=="1L1FA"&&status=="closed"&&balance==null)
   {
	 context.setVariable("objectId", "4");	            
   }
   else if(tillId=="t101"&&status=="closed"&&balance!=null)
   {
	 context.setVariable("objectId", "5");	            
   }
   else if(tillId=="1L1FB"&&status=="closed"&&balance==null)
   {
	 context.setVariable("objectId", "6");	            
   }
   else if(tillId=="1L1FB"&&status=="closed"&&balance!=null)
   {
	 context.setVariable("objectId", "7");	            
   }
  
  }
}






//var storeId=context.getVariable("storeId");

//var terminalId=context.getVariable("terminalId");

// var tillId=context.getVariable("tillId");

//var reqPayLoad = context.targetRequest.body.asJSON

//if(reqPayLoad!=null){
  
	//if((storeId != null) && (terminalId != null) && (tillId != null)){
 //     if((storeId != null) && (terminalId != null)){
	  
		// if((storeId != "") && (storeId=="1000") && (terminalId != "") && (terminalId=="t100") && (tillId != "") && (tillId=="t1"))	
	  //  if((storeId != "") && (storeId=="1000") && (terminalId != "") && (terminalId=="t100")) 
      //  {
	        // var tillId=reqPayLoad.tillId;
       //      var status=reqPayLoad.status;
       //      var balance = reqPayLoad.balance
          
	    //     context.setVariable("dataType","RetailStoresTill");
          
        //    if(status=="closed"&&balance==150){
	    //     	context.setVariable("objectId", "1");	            
	       //  }
	         
	       //  else if(tillId=="1L1FA"&&status=="closed"&&balance==150){
	       //  	context.setVariable("objectId", "1L1FA");	            
	       //  }
		   //   else if(tillId=="t101") {
	       //     context.setVariable("objectId", "t101");
	        // }
	    //  }
		
	//	}
//}