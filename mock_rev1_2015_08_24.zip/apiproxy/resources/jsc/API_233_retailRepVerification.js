var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null)
{
    context.setVariable('dataType', 'retailRepVerification');
    
    if((reqPayLoad.username=='johnsmith@mimomo.com' && reqPayLoad.password=='S0perS&ve')||(reqPayLoad.firstName=='Katty' && reqPayLoad.passcode=='98765432'))
    {  
      context.setVariable("objectId","1"); 
    }
    else if(reqPayLoad.username=='johnsmith@mimomo.com' && reqPayLoad.password=='S0pe')
    {  
      context.setVariable("objectId","2"); 
    }
    else if(reqPayLoad.firstName=='Katty' && reqPayLoad.passcode=='98765432')
	{
   		context.setVariable("objectId","3");
	}
}