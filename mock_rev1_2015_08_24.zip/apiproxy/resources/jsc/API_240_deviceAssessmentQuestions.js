context.setVariable('dataType', 'deviceAssessmentQuestions');
 context.setVariable("objectId", "001");