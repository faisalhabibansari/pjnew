var customerId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");
var reqPayLoad = context.targetRequest.body.asJSON;

if(reqPayLoad!=null)
{
  var numberSelected = reqPayLoad.numberSelected;
  context.setVariable('dataType', 'eipPost');
  if(customerId =='1234569' && accountId =='216228889' && numberSelected != null && numberSelected =='2061235555'){
      context.setVariable("objectId", "2061235555");
    }
   else if(customerId =='1234566' && accountId =='1230123' && numberSelected != null && numberSelected =='4253212928'){
      context.setVariable("objectId", "001");
    }
   else if(customerId =='1234567' && accountId =='1330124' && numberSelected != null && numberSelected =='4253212928'){
      context.setVariable("objectId", "002");
    }
   else if(customerId =='1234569' && accountId =='1330125' && numberSelected != null && numberSelected =='2062503333'){
      context.setVariable("objectId", "003");
    }
   else if(customerId =='1234570' && accountId =='1330125' && numberSelected != null && numberSelected =='4253212928'){
      context.setVariable("objectId", "004");
    }
   else if(customerId =='1234566' && accountId =='1230123' && numberSelected != null && numberSelected =='2063381111'){
      context.setVariable("objectId", "005");
    }
   else if(customerId =='1234567' && accountId =='1330124' && numberSelected != null && numberSelected =='4256032222'){
      context.setVariable("objectId", "006");
    }
   else if(customerId =='1234569' && accountId =='1330125' && numberSelected != null && numberSelected =='4256032222'){
      context.setVariable("objectId", "007");
    }
   else if(customerId =='1234570' && accountId =='1330125' && numberSelected != null && numberSelected =='4256032222'){
      context.setVariable("objectId", "008");
    }
}
