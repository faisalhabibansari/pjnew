context.setVariable("dataType","getDeviceDetails");
