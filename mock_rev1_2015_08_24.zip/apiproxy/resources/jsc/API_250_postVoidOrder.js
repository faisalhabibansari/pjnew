var req_payload = context.targetRequest.body.asJSON
var orderId=context.getVariable("objectId");
context.setVariable("dataType", "postVoidOrder");
if(req_payload!=null)
{
  if(req_payload.postVoidRequest!=null && req_payload.postVoidRequest!=undefined && req_payload.postVoidRequest.orderId==orderId)
  {
      context.setVariable("objectId", orderId);
  }
  else
  {
      context.setVariable("objectId", "0000");
  }
}