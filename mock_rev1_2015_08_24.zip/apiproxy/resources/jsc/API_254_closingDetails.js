var storeId=context.getVariable("request.queryparam.storeId");
var date=context.getVariable("request.queryparam.date");
if(storeId!='' && date!=''){
  context.setVariable("objectId", storeId);  
}else{
  context.setVariable("objectId", "000");  
}
context.setVariable("dataType","closingDetails");
