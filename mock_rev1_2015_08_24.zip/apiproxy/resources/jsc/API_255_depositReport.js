 var storeId=context.proxyRequest.queryParams['storeId'];
 var date=context.proxyRequest.queryParams['date'];

if(storeId!=''){
  context.setVariable("objectId", storeId);  
}else{
  context.setVariable("objectId", "000");  
}
context.setVariable("dataType","depositReport");

