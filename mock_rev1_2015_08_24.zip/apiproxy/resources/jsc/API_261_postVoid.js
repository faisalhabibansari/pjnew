
if(context.proxyRequest.queryParams!= null && context.proxyRequest.queryParams['storeId']!= null && context.proxyRequest.queryParams['date']!= null){
  var storeId=context.proxyRequest.queryParams['storeId'];
  var date=context.proxyRequest.queryParams['date'];
  
 	if(storeId!='') {
		context.setVariable("objectId",storeId); 
  		context.setVariable("dataType", "postVoid"); 
	}
}
