var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null)
{
context.setVariable("objectId","1234123");
context.setVariable("dataType","OffDeviceLineActivation");
}