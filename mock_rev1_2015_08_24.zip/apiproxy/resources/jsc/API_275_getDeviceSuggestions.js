
if(context.proxyRequest.queryParams!= null && context.proxyRequest.queryParams['source']!= null){
  
  var source=context.proxyRequest.queryParams['source'];

	if (source=='imeiMarketingSuggestions'){

		context.setVariable("objectId", "1000123422");
    	context.setVariable("dataType", "getDeviceSuggestions");
	}
}