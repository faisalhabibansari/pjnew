 var custId= context.getVariable("customerId");
 
  context.setVariable("dataType","cancelledLineReactivation");
	if(custId != null && custId != '') {
		context.setVariable("objectId", custId); 
	}
