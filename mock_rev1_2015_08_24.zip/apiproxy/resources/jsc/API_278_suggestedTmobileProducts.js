var imei=context.getVariable("request.queryparam.imei");
context.setVariable("dataType","suggestedTmobileProducts");
if(imei!=null && imei!=''){
	context.setVariable("objectId","1111");
}
else {
  context.setVariable("objectId","2222");
}
  