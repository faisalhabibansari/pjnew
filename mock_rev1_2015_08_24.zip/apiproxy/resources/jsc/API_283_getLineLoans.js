var quoteId=context.proxyRequest.queryParams['quoteId'];

/*if(quoteId!= '' && quoteId == '6542') {  
 context.setVariable("objectId", quoteId);
 context.setVariable("dataType","getLineLoans");

}else if(quoteId!= '' && quoteId == '6543'){
 context.setVariable("objectId", quoteId);
 context.setVariable("dataType","getLineLoans");

}else if (quoteId!= '' && quoteId == '3844'){
 context.setVariable("objectId", quoteId);
 context.setVariable("dataType","getLineLoans");

}*/

context.setVariable("objectId", quoteId);
context.setVariable("dataType","getLineLoans");