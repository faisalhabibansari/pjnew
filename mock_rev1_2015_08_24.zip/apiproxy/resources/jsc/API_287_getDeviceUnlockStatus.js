var imei = context.proxyRequest.queryParams['imei'];
var customerId = context.getVariable("customerID");
//context.setVariable("imei", imei);
context.setVariable("dataType", "getDeviceUnlockStatus");

if(customerId!=null && customerId!=''&& imei!='012345678905555'&& imei!='012345678901234' && imei!='012345678901235'
  && imei!='012345678901231' && imei!='0123456789012312' && imei!='0123456789012346'){
                context.setVariable("objectId",customerId); 
}
else if(imei=='012345678905555'){
  context.setVariable("objectId",'012345678905555');
  }
else if (customerId =='0123456789' && imei=='012345678901231'){
  context.setVariable("objectId",'012345678901231');
  }
else if(customerId =='0123456789' && imei=='0123456789012312'){
  context.setVariable("objectId",'0123456789012312');
  }
else if(customerId =='0123456789' && imei=='012345678901234'){ 
context.setVariable("objectId",'012345678901234'); 
}else if(customerId =='0123456789' && imei=='012345678901235'){ 
context.setVariable("objectId",'012345678901235'); 
}else if(customerId =='0123456789' && imei=='0123456789012346'){ 
context.setVariable("objectId",'0123456789012346'); 
}
//else if(customerId =='0123456789' && imei== null){
//context.setVariable("objectId",'0123456789');
//}
