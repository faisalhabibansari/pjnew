var custId = context.getVariable("customerId");
var accountId = context.getVariable("accountId");

var reqPayLoad = context.targetRequest.body.asJSON

var eipId = reqPayLoad.eipId;
var extraPaymentAmount = reqPayLoad.extraPaymentAmount;

context.setVariable("dataType","EIPEstimate");

//16 April/////////

if(custId == '12345' && accountId == '55555')
   {if(eipId == '111222333' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","5");
   }else if(eipId == '111222333' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","6");
   }else if(eipId == '111222334' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222334' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222355' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222355' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222366' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222366' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222335' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222335' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222378' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222378' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222388' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222388' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222337' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222338' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222339' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","5");
   }else if(eipId == '111222389' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","5");
   }
   }

 
/*if(custId == '12345' && accountId == '55555' && eipId == '20131008333384' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","1");
}else if(custId == '12345' && accountId == '55555' && eipId == '20131008333384' && extraPaymentAmount == '75.00'){
  context.setVariable("objectId","2");
}else if(custId == '12345' && accountId == '55555' && eipId == '20131008333384' && extraPaymentAmount == '100.00'){
  context.setVariable("objectId","3");
}else if(custId == '12345' && accountId == '55555' && eipId == '20131008333384' && extraPaymentAmount == '200.00'){
  context.setVariable("objectId","4");
}*/

//----7April----///////////////////

/*if(custId == '12345' && accountId == '55555')
   {if(eipId == '111222333' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","1");
   }else if(eipId == '111222334' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222355' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222333' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222366' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222335' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222378' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222388' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222337' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222338' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222339' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222389' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '20131008333384' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '20131008333384' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","2");
   }else if(eipId == '20131008333384' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","3");
   }else if(eipId == '20131008333384' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","4");
   }
   }else if(custId == '12345' && accountId == '55556')
   {if(eipId == '111222333' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","1");
   }else if(eipId == '111222334' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222355' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222333' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222366' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222335' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222378' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222388' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222337' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222338' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222339' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222389' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }
   }else if(custId == '55555' && accountId == '12345667')
   {if(eipId == '111222333' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","1");
   }else if(eipId == '111222334' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222355' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222333' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222366' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222335' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222378' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222388' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222337' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222338' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222339' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222389' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }
   }else if(custId == '123321' && accountId == '123321')
   {if(eipId == '111222333' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","1");
   }else if(eipId == '111222334' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222355' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222333' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222366' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222335' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222378' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222388' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222337' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222338' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222339' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222389' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }
   }else if(custId == '234234235' && accountId == '123456789')
   {if(eipId == '111222333' && extraPaymentAmount == '50.00'){
  context.setVariable("objectId","1");
   }else if(eipId == '111222334' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222355' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222333' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222366' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222335' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222378' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222388' && extraPaymentAmount == '200.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222337' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222338' && extraPaymentAmount == '50.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222339' && extraPaymentAmount == '75.00'){
     context.setVariable("objectId","1");
   }else if(eipId == '111222389' && extraPaymentAmount == '100.00'){
     context.setVariable("objectId","1");
   }
   }*/





