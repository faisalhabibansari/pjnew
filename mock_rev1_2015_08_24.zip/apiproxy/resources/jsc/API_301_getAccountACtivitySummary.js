var objectId = context.getVariable("objectId");
var accountId = context.getVariable("accountId");
if(accountId=='432432432')
{
context.setVariable("objectId", "432432432");
}
else if(accountId =='123123')
{
 	context.setVariable("objectId", "33348");
}
else{
  context.setVariable("objectId", objectId); 
  }
