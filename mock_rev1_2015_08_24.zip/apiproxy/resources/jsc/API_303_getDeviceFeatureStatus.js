var imei=context.getVariable("request.queryparam.imei");

context.setVariable("dataType",'getDeviceFeatureStatus');

context.setVariable("objectId","001");

