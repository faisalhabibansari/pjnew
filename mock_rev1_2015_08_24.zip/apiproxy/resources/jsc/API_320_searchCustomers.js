var msisdn=context.getVariable("request.queryparam.msisdn");
var accntNo=context.getVariable("request.queryparam.accntNo");
var businessId=context.getVariable("request.queryparam.businessId");
var email=context.getVariable("request.queryparam.email");
var taxId=context.getVariable("request.queryparam.taxId");
var firstName=context.getVariable("request.queryparam.firstName");
var lastName=context.getVariable("request.queryparam.lastName");
var govtId=context.getVariable("request.queryparam.govtId");
var imei=context.getVariable("request.queryparam.imei");
var imsi=context.getVariable("request.queryparam.imsi");
var macId=context.getVariable("request.queryparam.macId");
var orderId=context.getVariable("request.queryparam.orderId");
var sim=context.getVariable("request.queryparam.sim");
var ssnLast4=context.getVariable("request.queryparam.ssnLast4");
var ssn=context.getVariable("request.queryparam.ssn");
var street=context.getVariable("request.queryparam.street");
var city=context.getVariable("request.queryparam.city");
var state=context.getVariable("request.queryparam.state");
var zip=context.getVariable("request.queryparam.zip");
var orderStartDate=context.getVariable("request.queryparam.orderStartDate");
var orderEndDate=context.getVariable("request.queryparam.orderEndDate");
var ccLast4=context.getVariable("request.queryparam.ccLast4");


var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");
var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");

context.setVariable("dataType","searchCustomers");

if(!(msisdn===undefined) && (msisdn=='2062345688'))
{
 context.setVariable("objectId","001");
}
else if(!(accntNo===undefined) && (accntNo=='1234'))
{
 context.setVariable("objectId","002");
}
else if(businessId=='12mv')
{
 context.setVariable("objectId","003");
}
else if(email=='adamstommy@domain.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","004");
}
else if(email=='adamstommy@domain.com')
{
 context.setVariable("objectId","004");
}
else if(taxId=='0123')
{
 context.setVariable("objectId","005");
}
else if(firstName=='Da' && lastName=='Ma')
{
 context.setVariable("objectId","006");
}
else if(govtId=='13mca')
{
 context.setVariable("objectId","007");
}
else if(imei=='12345678910112')
{
 context.setVariable("objectId","008");
}
else if(imsi=='123456978912321' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc')
{
 context.setVariable("objectId","026");
}
else if(imsi=='123456978912321' && offset=='10' && limit=='10' && sort=='msisdn' && sortOrder=='asc')
{
 context.setVariable("objectId","027");
}
else if(imsi=='123456978912321')
{
 context.setVariable("objectId","009");
}
else if(macId=='123456789-abcd-45')
{
 context.setVariable("objectId","010");
}
else if(orderId=='ABCD12345E')
{
 context.setVariable("objectId","011");
}
else if(!(sim===undefined) && (sim=='1234567891234561111'))
{
 context.setVariable("objectId","012");
}
else if(ssnLast4=='1234')
{
 context.setVariable("objectId","013");
}
//else if(msisdn=='7788778606')
else if(msisdn=='7788778606' && offset==null && limit==null && sort==null && sortOrder==null)
{
 context.setVariable("objectId","014");
}
else if(email=='adams')
{
 context.setVariable("objectId","015");
}
else if(accntNo=='123456789')
{
 context.setVariable("objectId","016");
}
else if(businessId=='12mvd_0025')
{
 context.setVariable("objectId","017");
}
//else if(email=='adamstommy@domain.com')
//{
 //context.setVariable("objectId","018");
//}
else if(govtId=='13mca_0060')
{
 context.setVariable("objectId","019");
}
else if(orderId=='ABCD12345EFGH1234567891011121314')
{
 context.setVariable("objectId","020");
}
else if(ssn=='123456798')
{
 context.setVariable("objectId","021");
}
else if(taxId=='123456789')
{
 context.setVariable("objectId","022");
}
else if(imsi=='123456978912322')
{
 context.setVariable("objectId","023");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","024");
}
else if(msisdn=='7788778606' && offset=='0' && limit=='10' && sort=='msisdn' && sortOrder=='asc'){
	context.setVariable("objectId","025");
}

