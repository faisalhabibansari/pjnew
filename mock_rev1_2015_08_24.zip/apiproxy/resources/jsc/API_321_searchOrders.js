var email=context.getVariable("request.queryparam.email");
var accntNo=context.getVariable("request.queryparam.accntNo");
var street=context.getVariable("request.queryparam.street");
var city=context.getVariable("request.queryparam.city");
var state=context.getVariable("request.queryparam.state");
var zip=context.getVariable("request.queryparam.zip");
var agentId=context.getVariable("request.queryparam.agentId");
var cardNo=context.getVariable("request.queryparam.cardNo");
var dealerCode=context.getVariable("request.queryparam.dealerCode");
var taxId=context.getVariable("request.queryparam.taxId");
var firstName=context.getVariable("request.queryparam.firstName");
var lastName=context.getVariable("request.queryparam.lastName");
var imei=context.getVariable("request.queryparam.imei");
var orderId=context.getVariable("request.queryparam.orderId");
var rma=context.getVariable("request.queryparam.rma");
var storeId=context.getVariable("request.queryparam.storeId");
var trackingNo=context.getVariable("request.queryparam.trackingNo");
var msisdn=context.getVariable("request.queryparam.msisdn");
var ssnLast4=context.getVariable("request.queryparam.ssnLast4");
var terminalId=context.getVariable("request.queryparam.terminalId");
var offset=context.getVariable("request.queryparam.offset");
var limit=context.getVariable("request.queryparam.limit");

var sort=context.getVariable("request.queryparam.sort");
var sortOrder=context.getVariable("request.queryparam.sortOrder");

context.setVariable("dataType","searchOrders");

if(email=='johnadams@domain.com')
{
 context.setVariable("objectId","001");
}
else if(accntNo=='123456789')
{
 context.setVariable("objectId","002");
}
else if(street=='221bBakerStreet'&&city=='Marylebone'&&state=='22'&&zip=='12345')
{
 context.setVariable("objectId","003");
}
else if(agentId=='0123456')
{
 context.setVariable("objectId","004");
}
else if(cardNo=='123456789101112')
{
 context.setVariable("objectId","005");
}
else if(dealerCode=='1234567')
{
 context.setVariable("objectId","006");
}
//else if(email=='davidjames@domain.com')
else if(email=='davidjames@domain.com' && offset==null && limit==null && sort==null && sortOrder==null)
{
 context.setVariable("objectId","007");
}
else if(taxId=='012345678')
{
 context.setVariable("objectId","008");
}
else if(firstName=='Taylor'&&lastName=='James')
{
 context.setVariable("objectId","009");
}
else if(firstName=='Jim'&&lastName=='')
{
 context.setVariable("objectId","010");
}
else if(imei=='1234567891011')
{
 context.setVariable("objectId","011");
}
else if(orderId=='ABCD12345EFGHIJKL678910ABCDE123')
{
 context.setVariable("objectId","012");
}
else if(rma=='12345A67B89C1012')
{
 context.setVariable("objectId","013");
}
else if(storeId=='4321')
{
 context.setVariable("objectId","014");
}
else if(trackingNo=='12345ABCDEF12345')
{
 context.setVariable("objectId","015");
}
else if(msisdn=='2062345688')
{
 context.setVariable("objectId","016");
}
else if(ssnLast4=='1234'&&lastName=='Adams')
{
 context.setVariable("objectId","017");
}
else if(terminalId=='12'&&storeId=='1234')
{
 context.setVariable("objectId","018");
}
else if(imei=='12345678910111')
{
 context.setVariable("objectId","019");
}
else if(orderId=='ABCD12345EFGHIJKL678910ABCDE1234')
{
 context.setVariable("objectId","020");
}
else if(rma=='12345A67B89C10123')
{
 context.setVariable("objectId","021");
}
else if(imei=='12345678910111')
{
 context.setVariable("objectId","022");
}
else if(rma=='ABC12345678910123')
{
 context.setVariable("objectId","023");
}
else if(storeId=='9600')
{
 context.setVariable("objectId","024");
}
else if(storeId=='1234' && offset=='0' && limit=='10')
{
 context.setVariable("objectId","025");
}
else if(storeId=='1234' && offset=='10' && limit=='10')
{
 context.setVariable("objectId","026");
}
else if(storeId=='1234' && offset=='20' && limit=='10')
{
 context.setVariable("objectId","027");
}
else if(storeId=='9611' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","028");
}
else if(storeId=='9611' && offset=='10' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","029");
}
else if(storeId=='9611' && offset=='20' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","030");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='purchaseChannel' && sortOrder=='asc')
{
 context.setVariable("objectId","031");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='purchaseChannel' && sortOrder=='desc')
{
 context.setVariable("objectId","032");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='asc')
{
 context.setVariable("objectId","033");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderPlaced' && sortOrder=='desc')
{
 context.setVariable("objectId","034");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","035");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='desc')
{
 context.setVariable("objectId","036");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderId' && sortOrder=='asc')
{
 context.setVariable("objectId","037");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderId' && sortOrder=='desc')
{
 context.setVariable("objectId","038");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","039");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='orderStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","040");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='shippingStatus' && sortOrder=='asc')
{
 context.setVariable("objectId","041");
}
else if(msisdn=='7503339747' && offset=='0' && limit=='10' && sort=='shippingStatus' && sortOrder=='desc')
{
 context.setVariable("objectId","042");
}
else if(email=='davidjames@domain.com' && offset=='0' && limit=='10' && sort=='name' && sortOrder=='asc')
{
 context.setVariable("objectId","043");
}
else
{
  context.setVariable("objectId","000");
}



