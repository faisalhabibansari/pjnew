var q=context.getVariable("request.queryparam.q");
var promos=context.getVariable("request.queryparam.promos");

context.setVariable("dataType","getSearchPromotions");

if(q=="smart phone")
{
 context.setVariable("objectId","001");
}
else if(promos=="phone")
{
 context.setVariable("objectId","002");
}
else 
{
 context.setVariable("objectId","000");
}