var customerID=context.getVariable("customerID");
var accountId=context.getVariable("accountId");
var amount=context.getVariable("request.queryparam.amount");
var days=context.getVariable("request.queryparam.days");
var serviceId=context.getVariable("request.queryparam.serviceId");

context.setVariable("dataType",'getServiceTax');

if(amount!=null&&days==null&&serviceId==null)
{
context.setVariable("objectId","001");
}
else if(amount==null&&days!=null&&serviceId!=null)
{
context.setVariable("objectId","002");
}