var objectId = context.getVariable("objectId"); 
var lineId=context.getVariable("request.queryparam.lineId");
if(lineId!=null && objectId=='9832723' )
{
context.setVariable("objectId", "12345");
}

else if(lineId=='2061231235' && objectId=='123123'){
  context.setVariable("objectId", "123456");
  }
else if(lineId=='2061231236' && objectId=='123123'){
  context.setVariable("objectId", "1234567"); 
  }
else if(lineId=='2234459987' && objectId=='123123'){
  context.setVariable("objectId", "12345678"); 
  }
else if(lineId==null && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario7"); 
  }
else if(lineId==null && objectId=='123123'){
  context.setVariable("objectId", "api324scenario8"); 
  }
else if(lineId=='2061231235' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario9"); 
  }
else if(lineId=='2061231236' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario10"); 
  }
else if(lineId=='2234459987' && objectId=='1234123'){
  context.setVariable("objectId", "api324scenario11"); 
  }
  else if(lineId==null){
  context.setVariable("objectId", objectId); 
  }