var q = context.proxyRequest.queryParams['q'];
//var advantage=context.getVariable("request.queryparam.advantage"); there is no such parameter as "advantage" - this was not in the spec
var offset=context.getVariable("request.queryparam.offest");
var limit=context.getVariable("request.queryparam.limit");


if(q=='converse')
{
   	context.setVariable("objectId", "0001");
}
else if(q=='converse'&& offset=='0' && limit=='10')
{
    context.setVariable("objectId", "0002");
}
else
{
  	context.setVariable("objectId", "0000");
}