var request_payload = '';
if(context.getVariable('request.content')!=null && context.getVariable('request.content')!='')
{
  request_payload = JSON.parse(context.getVariable('request.content'));
}


context.setVariable("dataType","createCart");

var cartData = [];
for (i=0; i< request_payload.items.length; i++) {
  cartData.push(request_payload.items[i].productId);
}
//context.setVariable("cart",JSON.stringify(cartData));

 if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(123) != -1)  )
{
  context.setVariable("objectId","9002");
}

 else if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1) && (cartData.indexOf(101) != -1) && (cartData.indexOf(789) != -1)) {
context.setVariable("objectId","9001");
}
else if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(101) != -1)  && (cartData.indexOf(123)!= -1))
{
  context.setVariable("objectId","9003");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1)  && (cartData.indexOf(123) != -1))
{
  context.setVariable("objectId","9004");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1)  && (cartData.indexOf(123) != -1))
{
  context.setVariable("objectId","9005");
}
else if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1)  && (cartData.indexOf(456) != -1))
{
  context.setVariable("objectId","9006");
}
else if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(101) !=-1)  && (cartData.indexOf(456) != -1))
{
  context.setVariable("objectId","9007");
}


else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1)  && (cartData.indexOf(456) != -1))
{
  context.setVariable("objectId","9008");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1)  && (cartData.indexOf(456) != -1))
{
  context.setVariable("objectId","9009");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101) != -1)  && (cartData.indexOf(789) != -1))
{
  context.setVariable("objectId","9014");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100)!= -1)  && (cartData.indexOf(789) != -1))
{
  context.setVariable("objectId","9012");
}
else if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(101) != -1)  && (cartData.indexOf(789) != -1))
{
  context.setVariable("objectId","9010");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(100) != -1)  && (cartData.indexOf(786) != -1))
{
  context.setVariable("objectId","9013");
}
else if((cartData.indexOf("pln2511") != -1) && (cartData.indexOf(100) != -1)  && (cartData.indexOf(789) != -1))
{
  context.setVariable("objectId","9011");
}
else if((cartData.indexOf("pln2512") != -1) && (cartData.indexOf(101)!= -1)){
  
  context.setVariable("objectId","9015");

}
else if((cartData.indexOf("pln2517") != -1) && (cartData.indexOf(102)!= -1)){
  
  context.setVariable("objectId","9016");

}




