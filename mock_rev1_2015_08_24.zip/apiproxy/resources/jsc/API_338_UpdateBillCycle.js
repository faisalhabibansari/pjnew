var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null){
  	if(reqPayLoad.currentDate=='04/22/2015' && reqPayLoad.newDate=='05/05/2015'){
		context.setVariable("objectId", "0001");
	}else if(reqPayLoad.currentDate=='05/02/2015' && reqPayLoad.newDate=='05/17/2015'){
		context.setVariable("objectId", "0002");
	}else if(reqPayLoad.currentDate=='06/02/2015' && reqPayLoad.newDate=='06/17/2015'){
		context.setVariable("objectId", "0003");
	}else if(reqPayLoad.currentDate=='07/02/2015' && reqPayLoad.newDate=='07/17/2015'){
		context.setVariable("objectId", "0004");
	}
  else if(reqPayLoad.currentDueDate=='3/13/2015' && reqPayLoad.newDueDate=='3/23/2015'){
		context.setVariable("objectId", "0005");
	}
  else
   {
    context.setVariable("objectId","0000");
   }
}
else
{
    context.setVariable("objectId","0000");
}
context.setVariable("dataType","UpdateBillCycle");