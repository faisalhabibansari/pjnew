context.setVariable("dataType", "API_349_getProducts");
var qParams = context.proxyRequest.queryParams;
{
	if (qParams['lineId'] =='2061231235'&& qParams['soc']=='1000123456' && qParams['soc2']=='2000123456')
	{
	  	context.setVariable("objectId","001");
	} 
	else if(qParams['lineId'] =='2061231235' && qParams['soc']=='1000123456')
	{
	  	context.setVariable("objectId","002");
    }
  	else if(qParams['lineId'] =='2061231235' && qParams['soc']=='2000123456')
	{
	  	context.setVariable("objectId","003");
    }

}
/*if(qParams != null ) 
{
	if (qParams['soc'] != null && qParams['soc'] != "" && qParams['soc'] !=undefined)
	{
	  	context.setVariable("objectId",qParams['soc']);
	} 
	else if(qParams['lineId'] != null && qParams['lineId'] != "" && qParams['lineId'] != undefined)
	{
	  	context.setVariable("objectId",qParams['lineId']);
	}
	else
	{
	  	context.setVariable("objectId",'2061231235');
	}
}
else
{
  	context.setVariable("objectId",'2061231235');
}*/