var reqPayLoad = context.targetRequest.body.asJSON

if(reqPayLoad!=null){
context.setVariable("objectId","001");
context.setVariable("dataType",'CreateCustomerAndAccount');
}