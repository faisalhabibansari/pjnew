var req_payload = context.targetRequest.body.asJSON
var customerId=context.getVariable("customerId");
var accountId=context.getVariable("accountId");
//var lineId=context.getVariable("lineId");

context.setVariable("dataType", "BanEligibility");
//context.setVariable("objectId", "0000")

 if(req_payload!=null)
{
  if(req_payload.accountId=='56556')
  {
      context.setVariable("objectId",'56556');
  }
  else if(req_payload.accountId=='123123')
  {
      context.setVariable("objectId",'123123');
  }
  else if(req_payload.accountId=='123127')
  {
      context.setVariable("objectId",'123127');
  }
  else if(req_payload.accountId=='123456')
  {
      context.setVariable("objectId",'123456');
  }
  else
  {
      context.setVariable("objectId", "0000");
  }
}