var imsi=context.getVariable("request.queryparam.imsi");
context.setVariable("dataType",'ImsiStatus');
context.setVariable("objectId", "001");
