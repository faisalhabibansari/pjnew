var customerID = context.getVariable("customerId");

context.setVariable('dataType', 'customerLineAuthorization');

if(customerID != null){
  context.setVariable("objectId", customerId)
}