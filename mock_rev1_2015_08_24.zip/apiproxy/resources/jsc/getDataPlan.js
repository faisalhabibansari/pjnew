var id = context.getVariable("dataPlanId")

if(id!=null && id!=''){
  context.setVariable("objectId",id);
}else{
  context.setVariable("objectId",'000');
}
