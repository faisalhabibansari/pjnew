//Description---“WorkflowId” generation ///
//Developed by----Shailza////
//Date--24April2015//

context.setVariable("dataType","WorkflowRoute");
context.setVariable("objectId", '1'); 

