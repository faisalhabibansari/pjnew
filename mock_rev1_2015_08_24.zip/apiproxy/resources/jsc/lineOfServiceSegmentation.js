

//Grab query parameter corresponding to accountId
var accountId = context.proxyRequest.queryParams['AccountNumber'];
//var accountId = context.getVariable("request.queryparam.accountId");

//Grab query parameter corresponding to msisdn

var msisdn = context.proxyRequest.queryParams['MobileNumber'];
//var msisdn = context.getVariable("request.queryparam.msisdn");

//Grab query parameter corresponding to sim
var sim = context.proxyRequest.queryParams['sim'];
//var sim = context.getVariable("request.queryparam.sim");

//Grab query parameter corresponding to imsi
var imsi = context.proxyRequest.queryParams['imsi'];
//var imsi = context.getVariable("request.queryparam.imsi");

if(accountId!=null)
{
  
}
context.setVariable('msisdn', JSON.stringify(msisdn));
if(msisdn!=null)
{
  if(msisdn=='5157710122')
  {
	 context.proxyResponse.headers['SegmentationCode']='T';
  }
  if(msisdn=='5157710123')
  {
	 context.proxyResponse.headers['SegmentationCode']='P';
  }
  if(msisdn=='5157710124')
  {
	 context.proxyResponse.headers['SegmentationCode']='R';
  }
  if(msisdn=='5157710125')
  {
	 context.proxyResponse.headers['SegmentationCode']='S';
  }
  if(msisdn=='5157710126')
  {
	 context.proxyResponse.headers['SegmentationCode']='I';
  }
  if(msisdn=='5157710127')
  {
	 context.proxyResponse.headers['SegmentationCode']='J';
  }
  if(msisdn=='5157710128')
  {
	 context.proxyResponse.headers['SegmentationCode']='K';
  }
  if(msisdn=='5157710129')
  {
	 context.proxyResponse.headers['SegmentationCode']='U';
  }
  
}


if(sim!=null)
{  
  
}

if(imsi!=null)
{
	
}