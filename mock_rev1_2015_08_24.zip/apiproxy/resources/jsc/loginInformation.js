var msisdn=context.getVariable("request.queryparam.msisdn");
if(msisdn!=null && msisdn!=''){
  context.setVariable("objectId", "12346");  
}else{
  context.setVariable("objectId", "000");  
}
context.setVariable("dataType","loginInformation");