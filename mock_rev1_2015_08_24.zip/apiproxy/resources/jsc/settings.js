var senderId = context.getVariable("request.header.senderId");
var channelid = context.getVariable('request.header.channelid');
var applicationid = context.getVariable('request.header.applicationid');
var applicationuserid = context.getVariable('request.header.applicationuserid');
var sessionId = context.getVariable('request.header.sessionId');
var workflowId = context.getVariable('request.header.workflowId');
var activityId = context.getVariable('request.header.activityId');
var interactionId = context.getVariable('request.header.interactionId');
var timestamp = context.getVariable('request.header.ui-timestamp');
var dealerCode = context.getVariable('request.header.dealerCode');
var storeId = context.getVariable('request.header.storeId');
var tillId = context.getVariable('request.header.tillId');
var terminalId = context.getVariable('request.header.terminalId');


var headers = {'Content-Type' : 'application/json', 'senderId' : '', 'channelid' : '', 'applicationid' : '', 'applicationuserid' : '', 'sessionId' : '','workflowId' : '', 'activityId' : '', 'interactionId' : '', 'ui-timestamp' : '', 'dealerCode' : '', 'storeId' : '', 'scope' : '', 'tillId' : '', 'terminalId' : '', 'accept' : 'application/json'};

headers.senderId = senderId;
headers.channelid = channelid;
headers.applicationid = applicationid;
headers.applicationuserid = applicationuserid;
headers.sessionId = sessionId;
headers.workflowId = workflowId;
headers.activityId = activityId;
headers.interactionId = interactionId;
//headers.ui-timestamp = timestamp;
headers.dealerCode = dealerCode;
headers.storeId = storeId;
headers.tillId = tillId;
headers.terminalId = terminalId;



context.setVariable('headers', headers);