var reqPayLoad = context.targetRequest.body.asJSON
if(reqPayLoad!=null){
  
    	context.setVariable("objectId", "5089444941");
}else{
  context.setVariable("objectId", "");
}